# SRN Advanced Radar Upgrade

This package adds a dedicated `/radar` workstation while preserving the existing homepage radar and the rest of the repaired SRN website.

## Configured radar products

### Single-site NEXRAD
- IEM N0B high-resolution Base Reflectivity
- IEM N0U Base Velocity
- IEM N0S Storm-Relative Velocity
- IEM NET Net Echo Tops
- NOAA/NCEP OpenGeo Digital Hydrometeor Classification (BDHC)
- NOAA/NCEP OpenGeo one-hour rainfall accumulation (BOHA)
- NOAA/NCEP OpenGeo storm-total rainfall accumulation (BDSA)

### National / mosaic products
- NOAA/NCEP MRMS quality-controlled Composite Reflectivity (CONUS)
- NOAA/NCEP MRMS Enhanced Echo Tops / NEET (CONUS)
- IEM MRMS 1-hour, 24-hour and 72-hour precipitation mosaics (millimeters)
- RainViewer animated national reflectivity
- IEM CONUS NEXRAD reflectivity mosaic
- GOES-East visible, infrared and water-vapor imagery

## Products intentionally not fabricated

Correlation Coefficient (CC), Differential Reflectivity (ZDR), KDP and Spectrum Width remain visible in the product browser but disabled until a verified browser-renderable public raster source is integrated. These products exist in official WSR-88D data, but the site does not invent tile URLs, scrape commercial radar providers, or pretend raw binary Level II/III files are directly renderable in the browser.

## Radar workstation features
- National radar-site metadata from NOAA/NCEI with a built-in major-site fallback list
- Search by radar ID, city or state
- Nearest-radar selection using browser geolocation
- Clickable radar-site markers
- Approximately one hour of IEM scan history for supported animated single-site products
- Play/pause, previous/next, jump-to-newest, speed and loop controls
- Radar opacity control
- Full-screen radar mode
- Four-panel Storm Analysis view using REF / Base Velocity / SRV / HCA
- Map probe with coordinates, selected radar, distance, product and scan time; raw pixel values are explicitly not invented
- Product-specific reference legends
- Mobile collapsible radar controls
- Source attribution and direct link to official NWS radar

## Overlays
- NOAA state boundaries
- NOAA county boundaries
- NWS County Warning Area boundaries
- NEXRAD radar sites
- NWS Tornado Warnings
- NWS Severe Thunderstorm Warnings
- NWS Flash Flood Warnings
- NWS Tornado Watches
- NWS Severe Thunderstorm Watches
- IEM Local Storm Reports
- SPC Day 1 categorical outlook
- NHC active tropical systems

## Accuracy / source notes
- IEM publicly documents N0B, N0S, N0U and NET as processed single-radar products and provides RIDGE WMS plus scan-list services.
- NOAA/NCEP OpenGeo publicly lists SR_BREF, SR_BVEL, BDHC, BOHA and BDSA for WSR-88D sites and MRMS national composite products.
- IEM documents MRMS precipitation accumulation rasters in millimeters; the website labels those units accordingly.
- NHC storm coordinates are read from its numeric fields when available, with N/S/E/W string parsing as a fallback.
- Product availability can still vary by radar site or upstream service status. A blank or failed upstream layer is not replaced with fabricated data.

## Deployment
Netlify configuration remains at the repository root:
- Build command: `npm --workspace web run build`
- Publish directory: `dist/apps/web`
- SPA fallback: `/* /index.html 200`

## Validation completed in this repair environment
- Parsed all JavaScript/JSX source with the TypeScript parser: no syntax failures.
- Transpiled all JavaScript/JSX source in syntax-check mode: no errors.
- Checked local relative and `@/` imports: no unresolved source imports.
- Checked pure JavaScript radar modules with `node --check`.
- Confirmed no zero-byte source/public files or obvious empty internal links were introduced.

A full Vite production build could not be run locally because this exported package does not include `node_modules` and dependency installation is unavailable in this environment. Netlify will perform the real dependency install/build when this ZIP is deployed.

## Advanced Dual-Polarization Radar Fix — August 20, 2026

The professional radar workstation was extended without redesigning unrelated SRN pages.

- Correlation Coefficient (N0C), Differential Reflectivity (N0X/ZDR), and Specific Differential Phase (N0K/KDP) are now configured as real, selectable products.
- These products are retrieved from the public Unidata NEXRAD Level III AWS Open Data bucket and decoded in the visitor's browser; no commercial tiles or fabricated endpoints are used.
- A high-DPI Leaflet canvas layer renders the decoded polar radials while keeping warning polygons, site markers, and other vector overlays above the radar.
- The Storm Analysis quad now displays Base Reflectivity, Storm-Relative Velocity, Correlation Coefficient, and Differential Reflectivity.
- The mobile Radar Controls interface was changed to a true closable bottom sheet and only one product category expands at a time, preventing the controls from covering nearly the entire radar map.
- Dual-pol legends were aligned with the actual client-side color ramps.
- Browser-specific Vite compatibility handling was added for the Level III decoder package.
- Spectrum Width remains disabled until its exact public product feed and decoding/scaling path are verified for this viewer; SRN does not expose fake products merely to fill the menu.

The Level III products can take a moment to appear on phones because the current binary scan is downloaded and decoded locally. If a product is unavailable from the selected radar, the viewer reports that condition instead of substituting unrelated imagery.
