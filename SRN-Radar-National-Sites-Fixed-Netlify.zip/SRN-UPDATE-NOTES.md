# Storm Response Network website repair/update

This Hostinger Horizons export was reviewed and repaired for a cleaner public launch.

## Important configuration

Organization links and public-status text are centralized in:

`apps/web/src/config/site.js`

Current values include:
- Discord invite
- Facebook page
- Cash App support link and handle
- optional public contact email
- nonprofit-status notice
- operations status label and description

Update those values in one place instead of hunting through individual pages.

## Major repairs and additions

- Replaced the empty donation/checkout placeholder with a functioning Support page and Cash App link.
- Added direct SRN Discord calls-to-action in the header, mobile menu, homepage, footer, About page, Resources page, and Support page.
- Added an About page with a clear mission and independence disclaimer.
- Added a real 404 page for invalid routes.
- Added a mobile navigation menu; the original site hid its desktop navigation on small screens without a replacement.
- Added page title, description, favicon, theme color, robots file, and SPA rewrite support.
- Added smooth hash navigation for homepage sections.
- Replaced placeholder or overstated operations language with public-facing wording that distinguishes SRN information from official warnings and emergency instructions.
- Removed the unverified `ops@stormresponsenetwork.org` address. Until an organization-controlled public email is configured, public contact routes through the SRN Discord.
- Updated the training and resource library to current destinations, including SKYWARN, FEMA independent study, National Water Prediction Service, state emergency-management resources, and current ARRL ARES/RACES information.
- Repaired active-alert refresh behavior so background updates do not blank an already-loaded alert list during a transient request failure.
- Reworked the radar integration around the current RainViewer weather-map manifest, current IEM WMS products, NWS alert polygons, and IEM GeoJSON local storm reports.
- Removed unsupported RainViewer satellite/nowcast assumptions and unverified IEM radar-product entries that could produce broken map layers.
- Added HTML escaping to map popups before inserting third-party alert/report text.
- Removed Hostinger development/debug instrumentation from production Vite builds and stopped suppressing CSS/build warnings in the production configuration.
- Removed an empty source directory and scanned for zero-byte files and obvious user-facing placeholders.

## Deployment note

This is a React/Vite single-page app using `BrowserRouter`. Direct visits to application paths such as `/about` and `/donate` need to fall back to `index.html`. A Hostinger/Apache `.htaccess` rewrite is included in `apps/web/public/.htaccess` for deployments where Apache rewrite rules are honored. If you deploy somewhere else, configure that host's SPA fallback/rewrite feature.

## Donation/legal note

The Support page intentionally does not claim that contributions are tax-deductible. Update the nonprofit-status text in `site.js` only after the organization has the applicable formal recognition and is ready to make that statement publicly.

## Validation performed

- Parsed all project JavaScript/JSX source files successfully with a TypeScript parser in syntax-only mode.
- Checked local imports; no unresolved relative or `@/` source imports were found.
- Checked JavaScript/MJS configuration and tool files with Node syntax checks.
- Scanned the public source for common placeholders, dead empty links, obsolete URLs that had been identified during review, and zero-byte files.
- Regenerated `apps/web/public/llms.txt` after the new pages were added.

A full Vite production build was **not** completed in the repair environment because the exported project did not include installed dependencies and dependency installation was unavailable there. Run `npm install` and `npm run build` after importing/opening the project in a normal development or Hostinger environment. If that build reports an error, use the exact error output to make the next fix.
