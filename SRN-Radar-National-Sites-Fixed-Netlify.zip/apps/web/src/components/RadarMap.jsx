import React, { useEffect, useRef, useState, useCallback } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import {
    Radar, Play, Pause, SkipBack, SkipForward,
    TriangleAlert, MapPin, Eye, EyeOff, Loader2, RefreshCw, Layers,
} from 'lucide-react';

/* ------------------------------------------------------------------
   Data sources (all public, CORS-enabled, no API key)
   - RainViewer: animated national reflectivity tiles
   - IEM NEXRAD WMS: CONUS base reflectivity
   - IEM GOES WMS: CONUS visible / IR / water vapor
   - NWS api.weather.gov: active alerts / warning polygons
   - IEM: local storm reports (LSRs)
------------------------------------------------------------------- */
const RV_MANIFEST = 'https://api.rainviewer.com/public/weather-maps.json';
const NWS_ALERTS = 'https://api.weather.gov/alerts/active?status=actual&message_type=alert';
const IEM_LSR = 'https://mesonet.agron.iastate.edu/geojson/lsr.geojson?hours=48';
const IEM_WMS_BASE = 'https://mesonet.agron.iastate.edu/cgi-bin/wms/';

const RV_TILE = (host, path, size, color, smooth, snow) =>
    `${host}${path}/${size}/{z}/{x}/{y}/${color}/${smooth}_${snow}.png`;

/* Product catalogue — data driven so the layer effect stays generic. */
const PRODUCTS = [
    { id: 'rv-reflectivity', label: 'Reflectivity · RainViewer (animated)', type: 'rv-ref' },
    { id: 'iem-n0q', label: 'NEXRAD Base Reflectivity · IEM', type: 'iem', cgi: 'nexrad/n0q.cgi', layer: 'nexrad-n0q-900913' },
    { id: 'goes-vis', label: 'GOES-East Visible · CONUS', type: 'goes', cgi: 'goes_east.cgi', layer: 'conus_ch02' },
    { id: 'goes-ir', label: 'GOES-East Infrared · CONUS', type: 'goes', cgi: 'goes_east.cgi', layer: 'conus_ch13' },
    { id: 'goes-wv', label: 'GOES-East Water Vapor · CONUS', type: 'goes', cgi: 'goes_east.cgi', layer: 'conus_ch08' },
];

const RV_COLORS = [
    { id: 2, label: 'Universal Blue' },
    { id: 3, label: 'TITAN' },
    { id: 4, label: 'Weather Channel' },
    { id: 6, label: 'NEXRAD Level III' },
    { id: 7, label: 'Rainbow' },
    { id: 0, label: 'Black & White' },
];

const productById = (id) => PRODUCTS.find((p) => p.id === id);

/* NWS alert styling by event */
function alertStyle(event) {
    const e = (event || '').toLowerCase();
    if (e.includes('tornado warning')) return { color: '#ff2b2b', weight: 2.5, fillOpacity: 0.18, dashArray: null };
    if (e.includes('severe thunderstorm warning')) return { color: '#ffb020', weight: 2, fillOpacity: 0.14, dashArray: null };
    if (e.includes('flash flood warning')) return { color: '#22d3a6', weight: 2, fillOpacity: 0.12, dashArray: null };
    if (e.includes('flood warning')) return { color: '#3aa6ff', weight: 1.6, fillOpacity: 0.1, dashArray: null };
    if (e.includes('marine warning') || e.includes('boat')) return { color: '#7c5cff', weight: 1.6, fillOpacity: 0.1, dashArray: null };
    if (e.includes('tornado watch')) return { color: '#ffd23b', weight: 2, fillOpacity: 0.05, dashArray: '6 5' };
    if (e.includes('severe thunderstorm watch')) return { color: '#f5a623', weight: 2, fillOpacity: 0.05, dashArray: '6 5' };
    if (e.includes('watch')) return { color: '#9aa3b2', weight: 1.4, fillOpacity: 0.04, dashArray: '5 5' };
    return { color: '#6b7280', weight: 1.2, fillOpacity: 0.06, dashArray: null };
}

const LSR_STYLE = {
    T: { color: '#ff2b2b', label: 'Tornado' },
    H: { color: '#22d3a6', label: 'Hail' },
    G: { color: '#3aa6ff', label: 'Wind Gust' },
    D: { color: '#3aa6ff', label: 'Wind Damage' },
    W: { color: '#3aa6ff', label: 'Wind' },
    F: { color: '#7c5cff', label: 'Flash Flood' },
    V: { color: '#ffb020', label: 'Visibility' },
    M: { color: '#9aa3b2', label: 'Marine' },
    X: { color: '#9aa3b2', label: 'Other' },
};
const lsrStyle = (t) => LSR_STYLE[t] || LSR_STYLE.X;

function fmtClock(ts) {
    const d = new Date(ts * 1000);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }) +
        ' · ' + d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

export default function RadarMap() {
    const mapEl = useRef(null);
    const mapRef = useRef(null);
    const baseLayerRef = useRef(null);
    const radarLayerRef = useRef(null);
    const alertLayerRef = useRef(null);
    const lsrLayerRef = useRef(null);

    const [product, setProduct] = useState('rv-reflectivity');
    const [color, setColor] = useState(2);
    const [opacity, setOpacity] = useState(0.78);
    const [smooth, setSmooth] = useState(1);
    const [snow, setSnow] = useState(1);
    const [showAlerts, setShowAlerts] = useState(true);
    const [showLsr, setShowLsr] = useState(true);

    const [frames, setFrames] = useState([]);
    const [rvHost, setRvHost] = useState('https://tilecache.rainviewer.com');
    const [frameIndex, setFrameIndex] = useState(0);
    const [playing, setPlaying] = useState(true);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [alertCount, setAlertCount] = useState({ tornado: 0, severe: 0, flood: 0, watch: 0, other: 0 });
    const [lsrCount, setLsrCount] = useState(0);
    const [lastRefresh, setLastRefresh] = useState(null);

    const playRef = useRef(null);
    const buildKeyRef = useRef(null);
    const lastUrlRef = useRef(null);

    /* ---- init map once ---- */
    useEffect(() => {
        if (mapRef.current || !mapEl.current) return;
        const map = L.map(mapEl.current, {
            center: [39.5, -98.35],
            zoom: 5,
            zoomControl: true,
            attributionControl: true,
            worldCopyJump: true,
        });
        baseLayerRef.current = L.tileLayer(
            'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
            { attribution: '© OpenStreetMap, © CARTO, © RainViewer, © IEM, © NWS', maxZoom: 19, subdomains: 'abcd' }
        ).addTo(map);
        mapRef.current = map;
        return () => { map.remove(); mapRef.current = null; };
    }, []);

    /* ---- fetch RainViewer manifest ---- */
    const fetchManifest = useCallback(async (silent = false) => {
        if (!silent) setLoading(true);
        setError(null);
        try {
            const res = await fetch(RV_MANIFEST);
            if (!res.ok) throw new Error('Radar feed unavailable');
            const data = await res.json();
            const past = data.radar?.past || [];
            if (!past.length) throw new Error('No radar frames available');
            setRvHost(data.host || 'https://tilecache.rainviewer.com');
            setFrames(past);
            setFrameIndex(past.length - 1);
            setLastRefresh(Date.now());
        } catch (e) {
            setError(e.message);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { fetchManifest(); }, [fetchManifest]);

    /* ---- refresh manifest every 5 min ---- */
    useEffect(() => {
        const id = setInterval(() => fetchManifest(true), 5 * 60 * 1000);
        return () => clearInterval(id);
    }, [fetchManifest]);

    /* ---- animation loop ---- */
    useEffect(() => {
        if (playRef.current) clearInterval(playRef.current);
        if (product !== 'rv-reflectivity' || !playing || frames.length === 0) return;
        playRef.current = setInterval(() => {
            setFrameIndex((i) => (i + 1) % frames.length);
        }, 650);
        return () => clearInterval(playRef.current);
    }, [playing, frames, product]);

    /* ---- update radar tile layer (data-driven, blink-free) ---- */
    useEffect(() => {
        const map = mapRef.current;
        if (!map) return;
        const cfg = productById(product);
        if (!cfg) return;

        let url = null;
        if (cfg.type === 'rv-ref') {
            const frame = frames[frameIndex];
            if (!frame) return;
            url = RV_TILE(rvHost, frame.path, 256, color, smooth, snow);
        }

        // Build key captures everything that requires a fresh layer object.
        // Per-frame URL changes (animation) do NOT change the key, so we
        // swap tiles in place instead of remove/re-add — this stops blinking.
        const newBuildKey = cfg.type.startsWith('rv-')
            ? `rv|${cfg.type}|${color}|${smooth}|${snow}`
            : `wms|${cfg.cgi}|${cfg.layer}`;
        const existing = radarLayerRef.current;

        if (existing && buildKeyRef.current === newBuildKey) {
            if (url && url !== lastUrlRef.current) {
                existing.setUrl(url);
                lastUrlRef.current = url;
            }
            existing.setOpacity(opacity);
            return;
        }

        // Rebuild: product, color scheme, or WMS layer changed.
        if (existing) {
            map.removeLayer(existing);
            radarLayerRef.current = null;
        }

        let layer = null;
        if (url) {
            layer = L.tileLayer(url, { opacity, tileSize: 256, zIndex: 400, crossOrigin: true, maxNativeZoom: 7, maxZoom: 19 });
        } else if (cfg.type === 'iem' || cfg.type === 'goes') {
            layer = L.tileLayer.wms(`${IEM_WMS_BASE}${cfg.cgi}`, {
                layers: cfg.layer, format: 'image/png', transparent: true,
                opacity, zIndex: 400, crossOrigin: true,
            });
        }

        if (layer) {
            layer.addTo(map);
            radarLayerRef.current = layer;
            buildKeyRef.current = newBuildKey;
            lastUrlRef.current = url;
        }
    }, [product, color, smooth, snow, opacity, frames, frameIndex, rvHost]);

    /* ---- NWS alerts overlay ---- */
    const fetchAlerts = useCallback(async () => {
        const map = mapRef.current;
        if (!map) return;
        try {
            const res = await fetch(NWS_ALERTS, { headers: { Accept: 'application/geo+json' } });
            if (!res.ok) return;
            const data = await res.json();
            if (alertLayerRef.current) { map.removeLayer(alertLayerRef.current); }
            const gl = L.layerGroup();
            const counts = { tornado: 0, severe: 0, flood: 0, watch: 0, other: 0 };
            (data.features || []).forEach((f) => {
                const geom = f.geometry;
                const event = f.properties?.event || '';
                if (!geom || (geom.type !== 'Polygon' && geom.type !== 'MultiPolygon')) return;
                const st = alertStyle(event);
                const lyr = L.geoJSON(f, { style: () => st });
                lyr.bindPopup(`<b>${escapeHtml(event)}</b><br/>${escapeHtml(f.properties?.areaDesc || '')}<br/><span style="color:#9aa3b2">${escapeHtml(f.properties?.headline || '')}</span>`);
                lyr.addTo(gl);
                const e = event.toLowerCase();
                if (e.includes('tornado warning')) counts.tornado++;
                else if (e.includes('severe thunderstorm warning')) counts.severe++;
                else if (e.includes('flood warning') || e.includes('flash flood')) counts.flood++;
                else if (e.includes('watch')) counts.watch++;
                else counts.other++;
            });
            alertLayerRef.current = gl;
            if (showAlerts) gl.addTo(map);
            setAlertCount(counts);
        } catch { /* silent */ }
    }, [showAlerts]);

    useEffect(() => {
        fetchAlerts();
        const id = setInterval(fetchAlerts, 60 * 1000);
        return () => clearInterval(id);
    }, [fetchAlerts]);

    useEffect(() => {
        const map = mapRef.current;
        if (!map || !alertLayerRef.current) return;
        if (showAlerts) alertLayerRef.current.addTo(map);
        else map.removeLayer(alertLayerRef.current);
    }, [showAlerts]);

    /* ---- IEM local storm reports overlay ---- */
    const fetchLsr = useCallback(async () => {
        const map = mapRef.current;
        if (!map) return;
        try {
            const res = await fetch(IEM_LSR);
            if (!res.ok) return;
            const data = await res.json();
            if (lsrLayerRef.current) { map.removeLayer(lsrLayerRef.current); }
            const gl = L.layerGroup();
            const rows = data.features || data.lsr || data.events || [];
            let n = 0;
            rows.forEach((row) => {
                const props = row.properties || row;
                const coords = row.geometry?.type === 'Point' ? row.geometry.coordinates : null;
                const lat = coords?.[1] ?? props.lat ?? props.latitude;
                const lon = coords?.[0] ?? props.lon ?? props.lng ?? props.longitude;
                if (!Number.isFinite(Number(lat)) || !Number.isFinite(Number(lon))) return;

                const rawType = String(props.type || props.typetext || props.event || props.description || '').toLowerCase();
                let typeCode = String(props.type || '').toUpperCase();
                if (!LSR_STYLE[typeCode]) {
                    if (rawType.includes('tornado') || rawType.includes('funnel')) typeCode = 'T';
                    else if (rawType.includes('hail')) typeCode = 'H';
                    else if (rawType.includes('flash flood') || rawType.includes('flood')) typeCode = 'F';
                    else if (rawType.includes('wind damage') || rawType.includes('tree') || rawType.includes('power line')) typeCode = 'D';
                    else if (rawType.includes('wind') || rawType.includes('gust')) typeCode = 'G';
                    else if (rawType.includes('visibility') || rawType.includes('dust')) typeCode = 'V';
                    else typeCode = 'X';
                }

                const st = lsrStyle(typeCode);
                const magnitude = props.magnitude ?? props.mag;
                const unit = props.unit || props.units || '';
                const mag = magnitude != null && magnitude !== '' ? ` ${magnitude}${unit ? ` ${unit}` : ''}` : '';
                const city = props.city || props.location || '';
                const county = props.county || '';
                const state = props.state || '';
                const remark = props.remark || props.remarks || props.valid || props.timestamp || '';
                const displayType = props.typetext || props.event || props.description || st.label;

                const m = L.circleMarker([Number(lat), Number(lon)], {
                    radius: 5, color: st.color, weight: 1.5, fillColor: st.color, fillOpacity: 0.85,
                });
                m.bindPopup(`<b>${escapeHtml(displayType)}</b>${escapeHtml(mag)}<br/>${escapeHtml([city, county, state].filter(Boolean).join(' · '))}<br/><span style="color:#9aa3b2">${escapeHtml(remark)}</span>`);
                m.addTo(gl);
                n++;
            });
            lsrLayerRef.current = gl;
            if (showLsr) gl.addTo(map);
            setLsrCount(n);
        } catch { /* silent */ }
    }, [showLsr]);

    useEffect(() => {
        fetchLsr();
        const id = setInterval(fetchLsr, 5 * 60 * 1000);
        return () => clearInterval(id);
    }, [fetchLsr]);

    useEffect(() => {
        const map = mapRef.current;
        if (!map || !lsrLayerRef.current) return;
        if (showLsr) lsrLayerRef.current.addTo(map);
        else map.removeLayer(lsrLayerRef.current);
    }, [showLsr]);

    const cfg = productById(product);
    const isRV = cfg?.type?.startsWith('rv-');
    const currentFrame = frames[frameIndex];

    const toggle = (val, set, Icon, label, count) => (
        <button
            onClick={() => set(!val)}
            className={`flex items-center gap-2 border px-3 py-2 text-left transition-colors ${
                val
                    ? 'border-[hsl(var(--srn-status)/0.6)] bg-[hsl(var(--srn-status)/0.12)] text-[hsl(var(--srn-text))]'
                    : 'border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void))] text-[hsl(var(--srn-dim))]'
            }`}
        >
            {val ? <Eye className="h-3.5 w-3.5 srn-status-text" strokeWidth={2} /> : <EyeOff className="h-3.5 w-3.5" strokeWidth={2} />}
            <Icon className="h-3.5 w-3.5" strokeWidth={2} />
            <span className="font-data text-[10px] uppercase tracking-[0.16em]">{label}</span>
            {count != null && <span className="ml-auto font-data text-[10px] tabular-nums">{count}</span>}
        </button>
    );

    return (
        <div className="srn-panel overflow-hidden">
            {/* control bar */}
            <div className="flex flex-wrap items-center gap-3 border-b border-[hsl(var(--srn-line))] px-4 py-3">
                <span className="srn-chip"><Radar className="h-3.5 w-3.5" strokeWidth={2} />Live Radar</span>
                <span className="font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--srn-dim))]">
                    {isRV
                        ? (loading ? 'Syncing feed…' : error ? error : currentFrame ? fmtClock(currentFrame.time) : 'No frame available')
                        : 'Current public layer'}
                </span>
                <button
                    onClick={() => fetchManifest(false)}
                    className="ml-auto flex items-center gap-2 border border-[hsl(var(--srn-line))] px-3 py-1.5 font-data text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--srn-dim))] transition-colors hover:text-[hsl(var(--srn-text))]"
                >
                    <RefreshCw className="h-3.5 w-3.5" strokeWidth={2} />Refresh
                </button>
            </div>

            <div className="grid lg:grid-cols-[260px_1fr]">
                {/* side controls */}
                <div className="border-b border-[hsl(var(--srn-line))] p-4 lg:border-b-0 lg:border-r">
                    <div className="space-y-5">
                        {/* product */}
                        <div>
                            <p className="flex items-center gap-2 font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--srn-dim))]">
                                <Layers className="h-3.5 w-3.5" strokeWidth={2} />Radar Product
                            </p>
                            <select
                                aria-label="Radar or satellite product"
                                value={product}
                                onChange={(e) => setProduct(e.target.value)}
                                className="mt-2 max-h-[44px] w-full border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void))] px-3 py-2 font-data text-xs text-[hsl(var(--srn-text))] outline-none focus:border-[hsl(var(--srn-status)/0.6)]"
                            >
                                {PRODUCTS.map((p) => (
                                    <option key={p.id} value={p.id}>{p.label}</option>
                                ))}
                            </select>
                        </div>

                        {/* rainviewer color scheme */}
                        {product === 'rv-reflectivity' && (
                            <div>
                                <p className="font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--srn-dim))]">Color Scheme</p>
                                <select
                                    aria-label="RainViewer color scheme"
                                    value={color}
                                    onChange={(e) => setColor(Number(e.target.value))}
                                    className="mt-2 w-full border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void))] px-3 py-2 font-data text-xs text-[hsl(var(--srn-text))] outline-none focus:border-[hsl(var(--srn-status)/0.6)]"
                                >
                                    {RV_COLORS.map((c) => (
                                        <option key={c.id} value={c.id}>{c.label}</option>
                                    ))}
                                </select>
                            </div>
                        )}

                        {/* opacity */}
                        <div>
                            <p className="font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--srn-dim))]">
                                Layer Opacity · {Math.round(opacity * 100)}%
                            </p>
                            <input
                                aria-label="Weather layer opacity"
                                type="range" min={0} max={1} step={0.01} value={opacity}
                                onChange={(e) => setOpacity(Number(e.target.value))}
                                className="mt-2 w-full accent-[hsl(var(--srn-status))]"
                            />
                        </div>

                        {/* rainviewer toggles */}
                        {product === 'rv-reflectivity' && (
                            <div className="grid grid-cols-2 gap-2">
                                <button
                                    onClick={() => setSmooth(smooth ? 0 : 1)}
                                    className={`border px-2 py-1.5 font-data text-[10px] uppercase tracking-[0.14em] transition-colors ${
                                        smooth ? 'border-[hsl(var(--srn-status)/0.6)] bg-[hsl(var(--srn-status)/0.12)] text-[hsl(var(--srn-text))]' : 'border-[hsl(var(--srn-line))] text-[hsl(var(--srn-dim))]'
                                    }`}
                                >Smoothing</button>
                                <button
                                    onClick={() => setSnow(snow ? 0 : 1)}
                                    className={`border px-2 py-1.5 font-data text-[10px] uppercase tracking-[0.14em] transition-colors ${
                                        snow ? 'border-[hsl(var(--srn-status)/0.6)] bg-[hsl(var(--srn-status)/0.12)] text-[hsl(var(--srn-text))]' : 'border-[hsl(var(--srn-line))] text-[hsl(var(--srn-dim))]'
                                    }`}
                                >Snow Mode</button>
                            </div>
                        )}

                        {/* overlays */}
                        <div>
                            <p className="font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--srn-dim))]">Overlays</p>
                            <div className="mt-2 space-y-2">
                                {toggle(showAlerts, setShowAlerts, TriangleAlert, 'NWS Warnings', alertCount.tornado + alertCount.severe + alertCount.flood)}
                                {toggle(showLsr, setShowLsr, MapPin, 'Storm Reports', lsrCount)}
                            </div>
                        </div>

                        {/* alert legend */}
                        <div className="border-t border-[hsl(var(--srn-line))] pt-4">
                            <p className="font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--srn-dim))]">Active Warnings</p>
                            <ul className="mt-2 space-y-1.5 font-data text-[11px]">
                                <li className="flex items-center gap-2"><span className="h-2.5 w-2.5" style={{ background: '#ff2b2b' }} />Tornado <span className="ml-auto tabular-nums">{alertCount.tornado}</span></li>
                                <li className="flex items-center gap-2"><span className="h-2.5 w-2.5" style={{ background: '#ffb020' }} />Severe Tstorm <span className="ml-auto tabular-nums">{alertCount.severe}</span></li>
                                <li className="flex items-center gap-2"><span className="h-2.5 w-2.5" style={{ background: '#22d3a6' }} />Flash Flood <span className="ml-auto tabular-nums">{alertCount.flood}</span></li>
                                <li className="flex items-center gap-2"><span className="h-2.5 w-2.5 border border-dashed" style={{ background: '#ffd23b55', borderColor: '#ffd23b' }} />Watches <span className="ml-auto tabular-nums">{alertCount.watch}</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

                {/* map */}
                <div className="relative">
                    <div ref={mapEl} className="h-[460px] w-full bg-[hsl(var(--srn-void))] lg:h-[640px]" />
                    {isRV && loading && (
                        <div className="pointer-events-none absolute left-3 top-3 flex items-center gap-2 border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.85)] px-3 py-1.5 font-data text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--srn-dim))]">
                            <Loader2 className="h-3.5 w-3.5 animate-spin srn-status-text" strokeWidth={2} />Loading tiles
                        </div>
                    )}

                    {/* animation controls (RainViewer reflectivity) */}
                    {isRV && frames.length > 0 && (
                        <div className="absolute inset-x-0 bottom-0 flex items-center gap-3 border-t border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.92)] px-4 py-2.5 backdrop-blur">
                            <button
                                onClick={() => { setPlaying(false); setFrameIndex((i) => (i - 1 + frames.length) % frames.length); }}
                                className="grid h-8 w-8 place-items-center border border-[hsl(var(--srn-line))] text-[hsl(var(--srn-dim))] transition-colors hover:text-[hsl(var(--srn-text))]"
                            ><SkipBack className="h-4 w-4" strokeWidth={2} /></button>
                            <button
                                onClick={() => setPlaying((p) => !p)}
                                className="grid h-9 w-9 place-items-center srn-status-bg text-[hsl(var(--srn-status-ink))]"
                            >
                                {playing ? <Pause className="h-4 w-4" strokeWidth={2.25} /> : <Play className="h-4 w-4" strokeWidth={2.25} />}
                            </button>
                            <button
                                onClick={() => { setPlaying(false); setFrameIndex((i) => (i + 1) % frames.length); }}
                                className="grid h-8 w-8 place-items-center border border-[hsl(var(--srn-line))] text-[hsl(var(--srn-dim))] transition-colors hover:text-[hsl(var(--srn-text))]"
                            ><SkipForward className="h-4 w-4" strokeWidth={2} /></button>
                            <input
                                aria-label="Radar animation frame"
                                type="range" min={0} max={frames.length - 1} value={frameIndex}
                                onChange={(e) => { setPlaying(false); setFrameIndex(Number(e.target.value)); }}
                                className="flex-1 accent-[hsl(var(--srn-status))]"
                            />
                            <span className="font-data text-[10px] tabular-nums text-[hsl(var(--srn-dim))]">
                                {frameIndex + 1}/{frames.length}
                            </span>
                        </div>
                    )}
                </div>
            </div>

            {lastRefresh && (
                <div className="border-t border-[hsl(var(--srn-line))] px-4 py-2 font-data text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--srn-dim))]">
                    Radar frames refreshed {new Date(lastRefresh).toLocaleTimeString([], { hour12: false })} · radar 5 min · warnings 1 min · reports 5 min
                </div>
            )}
        </div>
    );
}
