import React from 'react';
import { Link } from 'react-router-dom';
import { SITE_CONFIG } from '@/config/site';

export default function SiteFooter() {
  return (
    <footer className="border-t border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel)/0.6)]">
      <div className="mx-auto max-w-[90rem] px-5 py-14 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <p className="font-cmd text-2xl font-bold uppercase tracking-[0.18em]">Storm Response Network</p>
            <p className="mt-3 max-w-md text-sm leading-relaxed text-[hsl(var(--srn-dim))]">Independent volunteer weather awareness, communications readiness, ground reporting, preparedness, and disaster-support coordination.</p>
            {SITE_CONFIG.contactEmail ? (
              <a href={`mailto:${SITE_CONFIG.contactEmail}`} className="mt-4 block break-all font-data text-xs uppercase tracking-[0.12em] text-[hsl(var(--srn-dim))] hover:text-[hsl(var(--srn-status))]">{SITE_CONFIG.contactEmail}</a>
            ) : (
              <a href={SITE_CONFIG.discordUrl} target="_blank" rel="noreferrer" className="mt-4 inline-block font-data text-xs uppercase tracking-[0.12em] text-[hsl(var(--srn-dim))] hover:text-[hsl(var(--srn-status))]">Contact SRN through Discord</a>
            )}
          </div>
          <div>
            <p className="font-data text-[10px] uppercase tracking-[0.24em] srn-status-text">Operations</p>
            <ul className="mt-4 space-y-2.5 font-cmd text-sm uppercase tracking-[0.12em] text-[hsl(var(--srn-dim))]">
              <li><Link to="/#status" className="hover:text-[hsl(var(--srn-text))]">National Status</Link></li>
              <li><Link to="/#radar" className="hover:text-[hsl(var(--srn-text))]">Live Radar</Link></li>
              <li><Link to="/radar" className="hover:text-[hsl(var(--srn-text))]">Advanced Radar</Link></li>
              <li><Link to="/alerts" className="hover:text-[hsl(var(--srn-text))]">Active Alerts</Link></li>
              <li><Link to="/training" className="hover:text-[hsl(var(--srn-text))]">Training</Link></li>
            </ul>
          </div>
          <div>
            <p className="font-data text-[10px] uppercase tracking-[0.24em] srn-status-text">Organization</p>
            <ul className="mt-4 space-y-2.5 font-cmd text-sm uppercase tracking-[0.12em] text-[hsl(var(--srn-dim))]">
              <li><Link to="/about" className="hover:text-[hsl(var(--srn-text))]">About SRN</Link></li>
              <li><Link to="/donate" className="hover:text-[hsl(var(--srn-text))]">Support SRN</Link></li>
              <li><a href={SITE_CONFIG.discordUrl} target="_blank" rel="noreferrer" className="hover:text-[hsl(var(--srn-text))]">Join Discord</a></li>
              <li><a href={SITE_CONFIG.facebookUrl} target="_blank" rel="noreferrer" className="hover:text-[hsl(var(--srn-text))]">Facebook</a></li>
            </ul>
          </div>
          <div>
            <p className="font-data text-[10px] uppercase tracking-[0.24em] srn-status-text">Official Sources</p>
            <ul className="mt-4 space-y-2.5 font-cmd text-sm uppercase tracking-[0.12em] text-[hsl(var(--srn-dim))]">
              <li><a href="https://www.weather.gov/" target="_blank" rel="noreferrer" className="hover:text-[hsl(var(--srn-text))]">National Weather Service</a></li>
              <li><a href="https://www.spc.noaa.gov/" target="_blank" rel="noreferrer" className="hover:text-[hsl(var(--srn-text))]">Storm Prediction Center</a></li>
              <li><a href="https://www.ready.gov/" target="_blank" rel="noreferrer" className="hover:text-[hsl(var(--srn-text))]">Ready.gov</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-[hsl(var(--srn-line))] pt-6">
          <p className="text-xs leading-relaxed text-[hsl(var(--srn-dim))]">Legal notice: Storm Response Network is an independent volunteer organization. It is not affiliated with, endorsed by, or acting on behalf of the National Weather Service, NOAA, FEMA, or any federal, state, tribal or local government agency. All references to official products are for attribution only. Nothing on this site constitutes an official warning, alert, or emergency instruction.</p>
          <p className="mt-3 text-xs leading-relaxed text-[hsl(var(--srn-dim))]">{SITE_CONFIG.nonprofitNotice}</p>
          <p className="mt-4 font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--srn-dim))]">© {new Date().getFullYear()} Storm Response Network · {SITE_CONFIG.tagline}</p>
        </div>
      </div>
    </footer>
  );
}
