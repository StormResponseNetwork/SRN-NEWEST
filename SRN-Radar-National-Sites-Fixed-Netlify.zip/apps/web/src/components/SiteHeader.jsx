import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Menu, Siren, X } from 'lucide-react';
import { SITE_CONFIG } from '@/config/site';

const navItems = [
  { to: '/', label: 'Operations', end: true },
  { to: '/alerts', label: 'Active Alerts' },
  { to: '/radar', label: 'Radar' },
  { to: '/training', label: 'Training' },
  { to: '/resources', label: 'Resources' },
  { to: '/about', label: 'About' },
  { to: '/donate', label: 'Support' },
];

export default function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.94)] backdrop-blur">
      <div className="mx-auto flex max-w-[90rem] items-center gap-4 px-5 py-3 lg:px-8">
        <Link to="/" onClick={() => setOpen(false)} className="flex items-center gap-3 transition-opacity hover:opacity-90">
          <div className="grid h-10 w-10 place-items-center border srn-status-border bg-[hsl(var(--srn-status)/0.1)]">
            <Siren className="h-5 w-5 srn-status-text" strokeWidth={1.75} />
          </div>
          <div className="leading-none">
            <p className="font-cmd text-lg font-bold uppercase tracking-[0.2em]">SRN</p>
            <p className="hidden font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--srn-dim))] sm:block">Storm Response Network</p>
          </div>
        </Link>

        <nav className="ml-auto hidden items-center gap-6 font-cmd text-sm uppercase tracking-[0.14em] text-[hsl(var(--srn-dim))] xl:flex">
          {navItems.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) => `transition-colors hover:text-[hsl(var(--srn-text))] ${isActive ? 'text-[hsl(var(--srn-text))]' : ''}`}
            >
              {n.label}
            </NavLink>
          ))}
          <a href={SITE_CONFIG.discordUrl} target="_blank" rel="noreferrer" className="border border-[hsl(var(--srn-status)/0.55)] bg-[hsl(var(--srn-status)/0.08)] px-3 py-2 text-[hsl(var(--srn-status))] transition-colors hover:bg-[hsl(var(--srn-status)/0.16)]">Join Discord</a>
        </nav>

        <span className="srn-chip ml-auto hidden sm:inline-flex xl:ml-0"><span className="srn-pip" />{SITE_CONFIG.operations.shortLabel}</span>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? 'Close navigation menu' : 'Open navigation menu'}
          aria-expanded={open}
          className="ml-auto grid h-10 w-10 place-items-center border border-[hsl(var(--srn-line))] text-[hsl(var(--srn-dim))] transition-colors hover:text-[hsl(var(--srn-text))] xl:hidden"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void))] px-5 py-4 xl:hidden">
          <nav className="mx-auto grid max-w-[90rem] gap-1 font-cmd text-base uppercase tracking-[0.14em]">
            {navItems.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.end}
                onClick={() => setOpen(false)}
                className={({ isActive }) => `border-b border-[hsl(var(--srn-line))] px-2 py-3 ${isActive ? 'text-[hsl(var(--srn-status))]' : 'text-[hsl(var(--srn-dim))]'}`}
              >
                {n.label}
              </NavLink>
            ))}
            <a href={SITE_CONFIG.discordUrl} target="_blank" rel="noreferrer" onClick={() => setOpen(false)} className="mt-3 srn-btn">Join SRN Discord</a>
          </nav>
        </div>
      )}
    </header>
  );
}
