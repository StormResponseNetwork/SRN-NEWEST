import React from 'react';
import { ChevronLeft, ChevronRight, Pause, Play, SkipForward } from 'lucide-react';

function fmt(d) {
  if (!d) return { utc: 'LIVE', local: '' };
  return {
    utc: `${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'UTC' })} UTC`,
    local: d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }),
  };
}

export default function AnimationBar({ frames, anim, enabled = true }) {
  const max = Math.max(0, frames.length - 1);
  const current = frames[anim.frameIndex] || null;
  const time = fmt(current);
  return (
    <div className="border-t border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.97)] p-2.5 shadow-[0_-8px_24px_rgba(0,0,0,0.28)] sm:p-3">
      <div className="flex items-center gap-2">
        <button type="button" disabled={!enabled || frames.length < 2} onClick={anim.prev} className="grid h-11 w-11 shrink-0 place-items-center border border-[hsl(var(--srn-line))] disabled:opacity-35 sm:h-10 sm:w-10" aria-label="Previous radar frame"><ChevronLeft className="h-4 w-4" /></button>
        <button type="button" disabled={!enabled || frames.length < 2} onClick={() => anim.setPlaying((v) => !v)} className="grid h-11 w-11 shrink-0 place-items-center border border-[hsl(var(--srn-status)/0.55)] text-[hsl(var(--srn-status))] disabled:opacity-35 sm:h-10 sm:w-10" aria-label={anim.playing ? 'Pause radar animation' : 'Play radar animation'}>{anim.playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}</button>
        <button type="button" disabled={!enabled || frames.length < 2} onClick={anim.next} className="grid h-11 w-11 shrink-0 place-items-center border border-[hsl(var(--srn-line))] disabled:opacity-35 sm:h-10 sm:w-10" aria-label="Next radar frame"><ChevronRight className="h-4 w-4" /></button>
        <button type="button" disabled={!enabled} onClick={anim.newest} className="hidden h-10 w-10 shrink-0 place-items-center border border-[hsl(var(--srn-line))] disabled:opacity-35 sm:grid" title="Jump to newest"><SkipForward className="h-4 w-4" /></button>
        <input aria-label="Radar frame" type="range" min="0" max={max} value={Math.min(anim.frameIndex,max)} onChange={(e) => anim.setFrameIndex(Number(e.target.value))} disabled={!enabled || frames.length < 2} className="min-w-0 flex-1 sm:min-w-[160px]" />
        <span className="shrink-0 text-right font-data text-[9px] uppercase tracking-[0.08em] text-[hsl(var(--srn-dim))] sm:min-w-28 sm:text-[10px]"><b className="block font-normal text-[hsl(var(--srn-text))]">{time.utc}</b>{time.local && <span className="hidden sm:block">{time.local} local</span>}</span>
        <select value={anim.speed} onChange={(e) => anim.setSpeed(Number(e.target.value))} className="hidden h-10 border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel))] px-2 font-data text-[10px] sm:block">
          <option value={1200}>0.5×</option><option value={800}>1×</option><option value={450}>2×</option><option value={250}>3×</option>
        </select>
        <label className="hidden h-10 items-center gap-1 border border-[hsl(var(--srn-line))] px-2 font-data text-[10px] uppercase text-[hsl(var(--srn-dim))] sm:flex"><input type="checkbox" checked={anim.loop} onChange={(e) => anim.setLoop(e.target.checked)} /> Loop</label>
      </div>
    </div>
  );
}
