import React, { useCallback, useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { IEM_RIDGE, RETINA_WMS_OPTIONS } from '@/lib/radar/providers';
import { fetchRecentLevel3Keys, fetchLevel3File } from '@/lib/radar/l3/awsLevel3';
import { decodeLevel3 } from '@/lib/radar/l3/decode';
import { getLevel3Product } from '@/lib/radar/l3/products';
import { createRadialLayer } from '@/lib/radar/l3/RadialLayer';

const PANELS = [
  { label: 'Base Reflectivity', code: 'N0B', source: 'iem' },
  { label: 'Storm-Relative Velocity', code: 'N0S', source: 'iem' },
  { label: 'Correlation Coefficient', code: 'N0C', source: 'aws', productId: 'cc' },
  { label: 'Differential Reflectivity', code: 'N0X', source: 'aws', productId: 'zdr' },
];

function MiniMap({ site, panel, register }) {
  const el = useRef(null);
  const [status, setStatus] = useState(panel.source === 'aws' ? 'Loading raw Level III…' : '');

  useEffect(() => {
    if (!el.current || !site) return undefined;
    const map = L.map(el.current, { zoomControl: false, attributionControl: false, preferCanvas: true }).setView([site.lat, site.lon], 7);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { maxZoom: 19, detectRetina: true }).addTo(map);
    const ctl = new AbortController();
    let radarLayer = null;

    if (panel.source === 'iem') {
      radarLayer = L.tileLayer.wms(IEM_RIDGE, {
        ...RETINA_WMS_OPTIONS,
        layers: 'single', sector: site.id, prod: panel.code,
        format: 'image/png', transparent: true, opacity: 0.82,
      }).addTo(map);
    } else {
      (async () => {
        try {
          setStatus('Loading raw Level III…');
          const rows = await fetchRecentLevel3Keys(site.id, panel.code, 1, ctl.signal);
          if (!rows.length) throw new Error('No scan');
          const raw = await fetchLevel3File(rows[0].key, ctl.signal);
          const decoded = await decodeLevel3(raw);
          if (ctl.signal.aborted) return;
          radarLayer = createRadialLayer(decoded, getLevel3Product(panel.productId), 0.84).addTo(map);
          setStatus(`${rows[0].time.toISOString().slice(11, 16)} UTC`);
        } catch (e) {
          if (e.name !== 'AbortError') setStatus('Product unavailable at this site');
        }
      })();
    }

    const unregister = register(map);
    const resize = setTimeout(() => map.invalidateSize(), 100);
    return () => {
      clearTimeout(resize);
      ctl.abort();
      unregister?.();
      if (radarLayer && map.hasLayer(radarLayer)) map.removeLayer(radarLayer);
      map.remove();
    };
  }, [site, panel, register]);

  return (
    <div className="relative min-h-[250px] overflow-hidden border border-[hsl(var(--srn-line))]">
      <div ref={el} className="absolute inset-0"/>
      <div className="pointer-events-none absolute left-2 top-2 z-[500] bg-[hsl(var(--srn-void)/0.92)] px-2 py-1 font-data text-[10px] uppercase tracking-[0.14em]">
        {panel.label}{status && <span className="ml-2 text-[8px] text-[hsl(var(--srn-dim))]">{status}</span>}
      </div>
    </div>
  );
}

export default function ComparisonGrid({ site, onClose }) {
  const mapsRef = useRef([]);
  const syncing = useRef(false);
  const register = useCallback((map) => {
    mapsRef.current = [...mapsRef.current, map];
    const sync = () => {
      if (syncing.current) return;
      syncing.current = true;
      try {
        const center = map.getCenter();
        const zoom = map.getZoom();
        mapsRef.current.forEach((m) => { if (m !== map) m.setView(center, zoom, { animate: false }); });
      } finally {
        syncing.current = false;
      }
    };
    map.on('moveend zoomend', sync);
    return () => {
      map.off('moveend zoomend', sync);
      mapsRef.current = mapsRef.current.filter((m) => m !== map);
    };
  }, []);

  useEffect(() => () => { mapsRef.current = []; }, []);

  return (
    <div className="fixed inset-0 z-[1200] overflow-y-auto bg-[hsl(var(--srn-void)/0.98)] p-3 sm:p-5">
      <div className="mx-auto max-w-[95rem]">
        <div className="mb-3 flex items-center justify-between gap-4">
          <div><p className="font-data text-[10px] uppercase tracking-[0.2em] srn-status-text">Storm Analysis Quad</p><h2 className="font-cmd text-2xl font-bold uppercase tracking-[0.08em]">{site.icao} · {site.city}</h2></div>
          <button type="button" onClick={onClose} className="srn-btn-outline min-h-10 px-4">Close</button>
        </div>
        <div className="grid gap-2 lg:grid-cols-2">{PANELS.map((panel) => <MiniMap key={panel.code} site={site} panel={panel} register={register}/>)}</div>
        <p className="mt-3 text-xs text-[hsl(var(--srn-dim))]">Reflectivity and SRV use verified IEM RIDGE imagery. CC and ZDR are decoded directly in your browser from the public Unidata/NOAA NEXRAD Level III AWS feed. All four panels stay synchronized while you pan or zoom.</p>
      </div>
    </div>
  );
}
