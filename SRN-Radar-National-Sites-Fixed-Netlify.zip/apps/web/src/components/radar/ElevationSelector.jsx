import React from 'react';

export default function ElevationSelector({ product }) {
  const label = product.elevation || (product.scope === 'site' ? 'Source-defined' : 'N/A');
  return (
    <div>
      <p className="mb-2 font-data text-[10px] uppercase tracking-[0.2em] srn-status-text">Elevation / Tilt</p>
      <div className="border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel-2)/0.35)] px-3 py-2.5 text-xs">
        <div className="flex items-center justify-between gap-3"><span>{label}</span><span className="font-data text-[9px] uppercase text-[hsl(var(--srn-dim))]">Verified source</span></div>
        <p className="mt-1 text-[10px] leading-relaxed text-[hsl(var(--srn-dim))]">Only elevations actually exposed by the configured public product source are shown. The current IEM single-site products are the lowest available Level III scans.</p>
      </div>
    </div>
  );
}
