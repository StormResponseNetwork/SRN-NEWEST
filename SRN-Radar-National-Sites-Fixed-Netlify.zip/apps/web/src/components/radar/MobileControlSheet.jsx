import React, { useEffect, useMemo, useState } from 'react';
import { Layers3, MapPin, SlidersHorizontal, Sparkles, X } from 'lucide-react';

const ICONS = { site: MapPin, products: SlidersHorizontal, layers: Layers3, tools: Sparkles };

export default function MobileControlSheet({ children, sections, onOpenChange }) {
  const [open, setOpen] = useState(false);
  const firstId = sections?.[0]?.id || 'controls';
  const [tab, setTab] = useState(firstId);
  useEffect(() => { onOpenChange?.(open); }, [open, onOpenChange]);
  useEffect(() => { if (sections?.length && !sections.some((s) => s.id === tab)) setTab(sections[0].id); }, [sections, tab]);
  const active = useMemo(() => sections?.find((s) => s.id === tab), [sections, tab]);

  return (
    <div className="lg:hidden">
      {!open && <button type="button" onClick={() => setOpen(true)} aria-expanded="false" className="absolute bottom-[5.35rem] left-1/2 z-[950] flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-full border border-[hsl(var(--srn-status)/0.65)] bg-[hsl(var(--srn-void)/0.96)] px-5 py-3 font-cmd text-sm font-bold uppercase tracking-[0.12em] text-[hsl(var(--srn-status))] shadow-2xl backdrop-blur"><SlidersHorizontal className="h-4 w-4"/>Radar Controls</button>}
      {open && <div className="fixed inset-x-0 bottom-0 z-[1250] flex max-h-[72svh] flex-col border-t border-[hsl(var(--srn-status)/0.45)] bg-[hsl(var(--srn-void)/0.99)] shadow-[0_-24px_70px_rgba(0,0,0,0.7)] backdrop-blur-xl">
        <div className="flex shrink-0 items-center justify-between border-b border-[hsl(var(--srn-line))] px-4 py-3"><div><p className="font-cmd text-sm font-bold uppercase tracking-[0.14em] srn-status-text">Radar Controls</p><p className="font-data text-[9px] uppercase tracking-[0.14em] text-[hsl(var(--srn-dim))]">Map stays active above</p></div><button type="button" onClick={() => setOpen(false)} className="grid h-10 w-10 place-items-center border border-[hsl(var(--srn-line))]" aria-label="Close radar controls"><X className="h-4 w-4"/></button></div>
        {sections?.length ? <>
          <div className="grid shrink-0 grid-cols-4 border-b border-[hsl(var(--srn-line))]">{sections.map((section) => { const Icon = ICONS[section.id] || SlidersHorizontal; const selected = section.id === tab; return <button key={section.id} type="button" onClick={() => setTab(section.id)} className={`flex min-h-14 flex-col items-center justify-center gap-1 border-r border-[hsl(var(--srn-line))] px-1 font-data text-[9px] uppercase tracking-[0.08em] last:border-r-0 ${selected ? 'bg-[hsl(var(--srn-status)/0.13)] text-[hsl(var(--srn-status))]' : 'text-[hsl(var(--srn-dim))]'}`}><Icon className="h-4 w-4"/>{section.label}</button>; })}</div>
          <div className="overscroll-contain overflow-y-auto px-4 py-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">{active?.content}</div>
        </> : <div className="overscroll-contain overflow-y-auto px-4 py-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">{children}</div>}
      </div>}
    </div>
  );
}
