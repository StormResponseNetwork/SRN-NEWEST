import React from 'react';

export const OVERLAY_OPTIONS = [
  ['radarSites','Radar Sites'],['states','State Boundaries'],['counties','County Boundaries'],['cwa','NWS CWA Boundaries'],
  ['tornadoWarning','Tornado Warnings'],['severeWarning','Severe T-Storm Warnings'],['flashFloodWarning','Flash Flood Warnings'],
  ['tornadoWatch','Tornado Watches'],['severeWatch','Severe T-Storm Watches'],['lsr','Local Storm Reports'],['spc','SPC Day 1 Outlook'],['nhc','NHC Tropical Systems']
];

export default function OverlayPanel({ overlays, onToggle }) {
  return <div><p className="mb-2 font-data text-[10px] uppercase tracking-[0.2em] srn-status-text">Map Overlays</p><div className="grid grid-cols-1 gap-1">{OVERLAY_OPTIONS.map(([id,label]) => <label key={id} className="flex items-center justify-between gap-3 border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel-2)/0.35)] px-3 py-2 text-xs"><span>{label}</span><input type="checkbox" checked={!!overlays[id]} onChange={() => onToggle(id)} /></label>)}</div></div>;
}
