import React, { useEffect, useMemo, useState } from 'react';
import { ChevronDown, RadioTower, RotateCw } from 'lucide-react';
import { PRODUCT_GROUPS, productSupportsSite } from '@/lib/radar/products';

export default function ProductMenu({ selectedId, onSelect, site }) {
  const selectedGroup = useMemo(
    () => PRODUCT_GROUPS.find((group) => group.products.some((product) => product.id === selectedId))?.id || PRODUCT_GROUPS[0]?.id,
    [selectedId],
  );
  const [openGroup, setOpenGroup] = useState(selectedGroup);
  useEffect(() => { if (selectedGroup) setOpenGroup(selectedGroup); }, [selectedGroup]);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-2">
        <p className="font-data text-[10px] uppercase tracking-[0.2em] srn-status-text">Radar Product</p>
        {site && <span className="rounded-full border border-[hsl(var(--srn-line))] px-2 py-1 font-data text-[9px] uppercase tracking-[0.1em] text-[hsl(var(--srn-dim))]">{site.type === 'TDWR' ? 'TDWR' : 'WSR-88D'}</span>}
      </div>
      {PRODUCT_GROUPS.map((group) => {
        const open = openGroup === group.id;
        return (
          <div key={group.id} className="overflow-hidden rounded-sm border border-[hsl(var(--srn-line))]">
            <button type="button" onClick={() => setOpenGroup((current) => (current === group.id ? null : group.id))} className="flex w-full items-center justify-between bg-[hsl(var(--srn-panel-2)/0.55)] px-3 py-3 font-cmd text-sm font-bold uppercase tracking-[0.12em]">
              {group.label}<ChevronDown className={`h-4 w-4 transition-transform ${open ? 'rotate-180' : ''}`} />
            </button>
            {open && <div>{group.products.map((p) => {
              const supported = productSupportsSite(p, site);
              return (
                <button key={p.id} type="button" disabled={!p.available} title={p.description} onClick={() => p.available && onSelect(p.id)} className={`flex min-h-14 w-full items-center gap-3 border-t border-[hsl(var(--srn-line))] px-3 py-3 text-left transition-colors ${p.available ? 'hover:bg-[hsl(var(--srn-panel-2))]' : 'cursor-not-allowed opacity-40'} ${selectedId === p.id ? 'bg-[hsl(var(--srn-status)/0.12)]' : ''}`}>
                  <span className="min-w-12 font-data text-[10px] uppercase tracking-[0.12em] srn-status-text">{p.short}</span>
                  <span className="flex-1">
                    <span className="block text-xs font-semibold">{p.label}</span>
                    {!supported && p.scope === 'site' && <span className="mt-1 inline-flex items-center gap-1 text-[9px] uppercase tracking-[0.08em] text-[hsl(var(--srn-amber))]"><RotateCw className="h-3 w-3" />Uses nearest WSR-88D</span>}
                  </span>
                  {p.scope === 'site' && <RadioTower className={`h-4 w-4 ${supported ? 'text-[hsl(var(--srn-status))]' : 'text-[hsl(var(--srn-amber))]'}`} />}
                </button>
              );
            })}</div>}
          </div>
        );
      })}
    </div>
  );
}
