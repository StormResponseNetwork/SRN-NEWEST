import React from 'react';
import { X } from 'lucide-react';

export default function RadarInspector({ value, onClose }) {
  if (!value) return null;
  const scan = value.scan ? new Date(value.scan) : null;
  const scanLabel = scan && !Number.isNaN(scan.getTime()) ? `${scan.toISOString().slice(11, 16)} UTC` : 'Latest imagery';
  const distance = Number.isFinite(value.distanceKm) ? `${value.distanceKm.toFixed(1)} km / ${(value.distanceKm * 0.621371).toFixed(1)} mi` : '—';
  return <div className="absolute bottom-20 left-3 z-[800] w-72 max-w-[calc(100%-1.5rem)] border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.96)] p-3 shadow-2xl"><div className="flex items-start justify-between gap-2"><p className="font-data text-[10px] uppercase tracking-[0.16em] srn-status-text">Radar Probe</p><button type="button" aria-label="Close radar probe" onClick={onClose}><X className="h-4 w-4" /></button></div><dl className="mt-2 grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-[10px]"><dt className="text-[hsl(var(--srn-dim))]">Position</dt><dd className="font-data">{value.lat.toFixed(4)}, {value.lon.toFixed(4)}</dd><dt className="text-[hsl(var(--srn-dim))]">Radar</dt><dd className="font-data">{value.site}</dd><dt className="text-[hsl(var(--srn-dim))]">Distance</dt><dd className="font-data">{distance}</dd><dt className="text-[hsl(var(--srn-dim))]">Product</dt><dd className="font-data">{value.product}</dd><dt className="text-[hsl(var(--srn-dim))]">Scan</dt><dd className="font-data">{scanLabel}</dd><dt className="text-[hsl(var(--srn-dim))]">Value</dt><dd className="font-data">Not available from rendered image tiles{value.unit ? ` (${value.unit})` : ''}</dd></dl></div>;
}
