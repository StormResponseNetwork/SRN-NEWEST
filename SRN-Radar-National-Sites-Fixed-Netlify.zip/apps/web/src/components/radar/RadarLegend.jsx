import React from 'react';
import { getColorTable } from '@/lib/radar/colorTables';

export default function RadarLegend({ product }) {
  const t = getColorTable(product.legend);
  if (t.type === 'categorical') {
    return <div className="srn-panel p-3"><p className="mb-2 font-data text-[11px] font-bold uppercase tracking-[0.18em] srn-status-text">Legend · {product.short}</p><div className="grid grid-cols-2 gap-x-3 gap-y-1">{t.classes.map(([code, label]) => <div key={code} className="text-[10px] text-[hsl(var(--srn-dim))]"><b className="mr-1 text-[hsl(var(--srn-text))]">{code}</b>{label}</div>)}</div></div>;
  }
  return <div className="srn-panel p-3"><p className="mb-2 font-data text-[11px] font-bold uppercase tracking-[0.18em] srn-status-text">Legend · {product.short}</p><div className="h-4 w-full rounded-sm border border-white/20" style={{ background: t.background }} /><div className="mt-1.5 flex justify-between font-data text-[9px] font-medium text-[hsl(var(--srn-text)/0.82)]"><span>{t.min}</span>{t.center && <span>{t.center}</span>}<span>{t.max}</span></div></div>;
}
