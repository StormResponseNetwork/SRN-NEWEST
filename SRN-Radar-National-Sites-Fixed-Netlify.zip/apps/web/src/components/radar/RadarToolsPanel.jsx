import React from 'react';
import { Circle, Crosshair, Ruler, Trash2 } from 'lucide-react';

export default function RadarToolsPanel({ rangeRings, onToggleRangeRings, measureMode, onToggleMeasure, measureResult, onClearMeasure, probeMode, onToggleProbe }) {
  return (
    <div>
      <p className="mb-2 font-data text-[10px] uppercase tracking-[0.2em] srn-status-text">Radar Tools</p>
      <div className="grid gap-1 sm:grid-cols-2 lg:grid-cols-1">
        <label className="flex min-h-11 items-center justify-between gap-3 rounded-sm border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel-2)/0.35)] px-3 py-2 text-xs"><span className="flex items-center gap-2"><Circle className="h-4 w-4 srn-status-text"/>Range rings</span><input type="checkbox" checked={rangeRings} onChange={onToggleRangeRings}/></label>
        <button type="button" onClick={onToggleMeasure} className={`flex min-h-11 w-full items-center justify-between gap-3 rounded-sm border px-3 py-2 text-left text-xs ${measureMode ? 'border-[hsl(var(--srn-status)/0.7)] bg-[hsl(var(--srn-status)/0.12)]' : 'border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel-2)/0.35)]'}`}><span className="flex items-center gap-2"><Ruler className="h-4 w-4 srn-status-text"/>Distance / bearing</span><span className="font-data text-[9px] uppercase srn-status-text">{measureMode ? 'Active' : 'Off'}</span></button>
        <button type="button" onClick={onToggleProbe} className={`flex min-h-11 w-full items-center justify-between gap-3 rounded-sm border px-3 py-2 text-left text-xs ${probeMode ? 'border-[hsl(var(--srn-status)/0.7)] bg-[hsl(var(--srn-status)/0.12)]' : 'border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel-2)/0.35)]'}`}><span className="flex items-center gap-2"><Crosshair className="h-4 w-4 srn-status-text"/>Radar probe</span><span className="font-data text-[9px] uppercase srn-status-text">{probeMode ? 'Active' : 'Off'}</span></button>
      </div>
      {(measureMode || probeMode) && <p className="mt-2 text-[10px] leading-relaxed text-[hsl(var(--srn-dim))]">{measureMode ? 'Tap two points on the map to measure distance and bearing.' : 'Tap the map to inspect location, selected product and distance from the radar.'}</p>}
      {measureResult && <div className="mt-2 flex items-center justify-between gap-3 rounded-sm border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.55)] px-3 py-2"><div><p className="font-data text-[10px] uppercase text-[hsl(var(--srn-text))]">{measureResult.miles.toFixed(1)} mi · {measureResult.km.toFixed(1)} km</p><p className="font-data text-[9px] uppercase text-[hsl(var(--srn-dim))]">Bearing {Math.round(measureResult.bearing)}°</p></div><button type="button" onClick={onClearMeasure} className="grid h-9 w-9 place-items-center border border-[hsl(var(--srn-line))]" title="Clear measurement"><Trash2 className="h-4 w-4"/></button></div>}
    </div>
  );
}
