import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Expand, Grid2X2, LocateFixed, Minimize, RefreshCw, Ruler, TriangleAlert } from 'lucide-react';
import SiteSelector from './SiteSelector';
import ProductMenu from './ProductMenu';
import ElevationSelector from './ElevationSelector';
import RadarLegend from './RadarLegend';
import AnimationBar from './AnimationBar';
import OverlayPanel from './OverlayPanel';
import SiteInfoPanel from './SiteInfoPanel';
import RadarInspector from './RadarInspector';
import MobileControlSheet from './MobileControlSheet';
import ComparisonGrid from './ComparisonGrid';
import RadarToolsPanel from './RadarToolsPanel';
import useRadarAnimation from '@/hooks/useRadarAnimation';
import {
  FALLBACK_RADAR_SITES,
  bearingBetween,
  destinationPoint,
  haversineDistanceKm,
  nearestSite,
  nearestWsrSite,
} from '@/lib/radar/sites';
import { findProduct, isSiteProduct, productSupportsSite, resolveSiteSource, QUICK_PRODUCTS } from '@/lib/radar/products';
import {
  IEM_WMS_BASE,
  IEM_RIDGE,
  NOAA_REFERENCE_WMS,
  NOAA_BOUNDARY_LAYERS,
  RETINA_WMS_OPTIONS,
  fetchRadarSites,
  fetchScanTimes,
  ridgeParams,
  noaaOpenGeoWms,
  noaaOpenGeoLayer,
  fetchNwsAlerts,
  fetchLsr,
  fetchSpcOutlook,
  fetchNhcStorms,
  fetchRainViewer,
  rainViewerTile,
  regionalBrefFallback,
} from '@/lib/radar/providers';
import { fetchRecentLevel3Keys, fetchLevel3File } from '@/lib/radar/l3/awsLevel3';
import { decodeLevel3 } from '@/lib/radar/l3/decode';
import { getLevel3Product } from '@/lib/radar/l3/products';
import { createRadialLayer } from '@/lib/radar/l3/RadialLayer';

const defaultOverlays = {
  radarSites: true,
  states: true,
  counties: false,
  cwa: false,
  tornadoWarning: true,
  severeWarning: true,
  flashFloodWarning: true,
  tornadoWatch: true,
  severeWatch: true,
  lsr: true,
  spc: false,
  nhc: false,
  rangeRings: false,
};

const RANGE_RINGS = [25, 50, 75, 100].map((miles) => ({ miles, km: miles * 1.609344 }));

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function alertStyle(event) {
  const e = String(event || '').toLowerCase();
  if (e.includes('tornado warning')) return { color: '#ff2424', weight: 3.5, opacity: 1, fillOpacity: 0.23 };
  if (e.includes('severe thunderstorm warning')) return { color: '#ffb020', weight: 2.6, opacity: 1, fillOpacity: 0.18 };
  if (e.includes('flash flood warning')) return { color: '#22d3a6', weight: 2.5, opacity: 1, fillOpacity: 0.16 };
  if (e.includes('tornado watch')) return { color: '#ffe047', weight: 2.3, opacity: 0.95, fillOpacity: 0.055, dashArray: '6 5' };
  if (e.includes('severe thunderstorm watch')) return { color: '#f5a623', weight: 2.2, opacity: 0.95, fillOpacity: 0.05, dashArray: '6 5' };
  return { color: '#9aa3b2', weight: 1.3, opacity: 0.85, fillOpacity: 0.04 };
}

function alertEnabled(event, o) {
  const e = String(event || '').toLowerCase();
  if (e.includes('tornado warning')) return o.tornadoWarning;
  if (e.includes('severe thunderstorm warning')) return o.severeWarning;
  if (e.includes('flash flood warning')) return o.flashFloodWarning;
  if (e.includes('tornado watch')) return o.tornadoWatch;
  if (e.includes('severe thunderstorm watch')) return o.severeWatch;
  return false;
}

function parseCoordinate(value, numericValue, axis) {
  const direct = Number(numericValue);
  if (Number.isFinite(direct)) return direct;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const raw = String(value ?? '').trim().toUpperCase();
  const match = raw.match(/^(-?\d+(?:\.\d+)?)\s*([NSEW])?$/);
  if (!match) return NaN;
  let n = Number(match[1]);
  if (!Number.isFinite(n)) return NaN;
  const hemi = match[2];
  if (hemi === 'S' || hemi === 'W') n = -Math.abs(n);
  if (hemi === 'N' || hemi === 'E') n = Math.abs(n);
  if (axis === 'lat' && (n < -90 || n > 90)) return NaN;
  if (axis === 'lon' && (n < -180 || n > 180)) return NaN;
  return n;
}

export default function RadarWorkstation() {
  const mapEl = useRef(null);
  const mapRef = useRef(null);
  const radarLayerRef = useRef(null);
  const radarPendingLayerRef = useRef(null);
  const radarBuildKey = useRef('');
  const overlayRefs = useRef({});
  const latestRef = useRef({});
  const opacityRef = useRef(0.82);
  const measureModeRef = useRef(false);
  const probeModeRef = useRef(false);
  const l3LayerRef = useRef(null);
  const l3CacheRef = useRef(new Map());
  const l3IdentityRef = useRef('');

  const [sites, setSites] = useState(FALLBACK_RADAR_SITES);
  const [sitesLoading, setSitesLoading] = useState(true);
  const [site, setSite] = useState(FALLBACK_RADAR_SITES[0]);
  const [productId, setProductId] = useState('n0b');
  const product = findProduct(productId);
  const [scanFrames, setScanFrames] = useState([]);
  const [rvFrames, setRvFrames] = useState([]);
  const [l3Frames, setL3Frames] = useState([]);
  const [l3Loading, setL3Loading] = useState(false);
  const [rvHost, setRvHost] = useState('https://tilecache.rainviewer.com');
  const [opacity, setOpacity] = useState(0.82);
  const [overlays, setOverlays] = useState(defaultOverlays);
  const [error, setError] = useState('');
  const [inspector, setInspector] = useState(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [comparison, setComparison] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [measureMode, setMeasureMode] = useState(false);
  const [probeMode, setProbeMode] = useState(false);
  const [measurePoints, setMeasurePoints] = useState([]);
  const [dataSourceLabel, setDataSourceLabel] = useState('Loading radar feed…');

  const displayFrames = useMemo(() => {
    if (product.source === 'rainviewer') return rvFrames.map((f) => new Date(f.time * 1000));
    if (product.source === 'aws-level3') return l3Frames.map((f) => f.time);
    return scanFrames;
  }, [product.source, rvFrames, l3Frames, scanFrames]);
  const anim = useRadarAnimation(Math.max(displayFrames.length, 1), false);
  const activeFrame = displayFrames[anim.frameIndex] || null;
  const measureResult = useMemo(() => {
    if (measurePoints.length !== 2) return null;
    const [a, b] = measurePoints;
    const km = haversineDistanceKm(a.lat, a.lng, b.lat, b.lng);
    return {
      km,
      miles: km / 1.609344,
      bearing: bearingBetween(a.lat, a.lng, b.lat, b.lng),
    };
  }, [measurePoints]);

  latestRef.current = { site, product, activeFrame };
  opacityRef.current = opacity;
  measureModeRef.current = measureMode;
  probeModeRef.current = probeMode;

  const handleSiteSelect = useCallback((nextSite) => {
    if (!nextSite) return;
    const currentProduct = findProduct(productId);
    setSite(nextSite);
    setInspector(null);
    setMeasurePoints([]);
    radarBuildKey.current = '';
    l3IdentityRef.current = '';
    if (isSiteProduct(currentProduct) && !productSupportsSite(currentProduct, nextSite)) {
      setProductId('n0b');
      setError(`${currentProduct.short} is not produced by ${nextSite.icao}. Switched to Base Reflectivity.`);
    } else {
      setError('');
    }
  }, [productId]);

  useEffect(() => {
    const ctl = new AbortController();
    fetchRadarSites(ctl.signal)
      .then((rows) => {
        setSites(rows);
        setSite((current) => rows.find((candidate) => candidate.icao === current?.icao) || current);
      })
      .catch(() => setSites(FALLBACK_RADAR_SITES))
      .finally(() => setSitesLoading(false));
    return () => ctl.abort();
  }, []);

  useEffect(() => {
    if (!mapEl.current || mapRef.current) return undefined;
    const map = L.map(mapEl.current, { zoomControl: true, preferCanvas: true, fadeAnimation: true }).setView([36.2, -98.5], 5);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      maxZoom: 19,
      detectRetina: true,
      attribution: '&copy; OpenStreetMap &copy; CARTO',
    }).addTo(map);
    map.on('click', (e) => {
      if (measureModeRef.current) {
        setInspector(null);
        setMeasurePoints((points) => (points.length >= 2 ? [e.latlng] : [...points, e.latlng]));
        return;
      }
      if (!probeModeRef.current) return;
      const current = latestRef.current;
      const distanceKm = current.site ? haversineDistanceKm(e.latlng.lat, e.latlng.lng, current.site.lat, current.site.lon) : null;
      setInspector({ lat: e.latlng.lat, lon: e.latlng.lng, site: current.site?.icao || '—', product: current.product?.label || '—', unit: current.product?.unit || '', scan: current.activeFrame?.toISOString?.() || null, distanceKm });
    });
    mapRef.current = map;
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!mapRef.current) return undefined;
    const timer = setTimeout(() => mapRef.current?.invalidateSize(), 80);
    return () => clearTimeout(timer);
  }, [fullscreen]);

  useEffect(() => {
    if (!fullscreen) return undefined;
    const previousOverflow = document.body.style.overflow;
    const onKeyDown = (event) => {
      if (event.key === 'Escape') setFullscreen(false);
    };
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', onKeyDown);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [fullscreen]);

  useEffect(() => {
    if (!mapRef.current || !site || !isSiteProduct(product)) return;
    mapRef.current.flyTo([site.lat, site.lon], Math.max(mapRef.current.getZoom(), 7), { duration: 0.5 });
  }, [site, product]);

  useEffect(() => {
    if (!site || !isSiteProduct(product) || productSupportsSite(product, site)) return;
    setProductId('n0b');
    setError(`${site.icao} is ${site.type === 'TDWR' ? 'a TDWR' : 'not compatible with that product'}. Switched to Base Reflectivity.`);
    setInspector(null);
  }, [site?.icao]); // Product changes are handled explicitly by handleProductSelect.


  useEffect(() => {
    setError('');
    setScanFrames([]);
    anim.setPlaying(false);
    const archive = resolveSiteSource(product, site, 'archive');
    if (!(product.animated && site && archive?.source === 'iem-ridge' && productSupportsSite(product, site))) return undefined;
    const ctl = new AbortController();
    fetchScanTimes(site.iemId || site.id, archive.code, ctl.signal, 60)
      .then((rows) => { setScanFrames(rows); anim.setFrameIndex(Math.max(0, rows.length - 1)); })
      .catch((e) => { if (e.name !== 'AbortError') setError('Radar history is temporarily unavailable. Live radar is still active.'); });
    return () => ctl.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [site?.icao, product.id, refreshKey]);

  useEffect(() => {
    setL3Frames([]);
    if (product.source !== 'aws-level3' || !site || !productSupportsSite(product, site)) return undefined;
    const ctl = new AbortController();
    setError('');
    fetchRecentLevel3Keys(site.id, product.code, 12, ctl.signal)
      .then((rows) => {
        if (!rows.length) throw new Error('No recent scans');
        setL3Frames(rows);
        anim.setFrameIndex(Math.max(0, rows.length - 1));
      })
      .catch((e) => {
        if (e.name !== 'AbortError') {
          setError(`${product.short} Level III data is unavailable for ${site.icao}. Switched to Base Reflectivity so the radar stays usable.`);
          setProductId('n0b');
          radarBuildKey.current = '';
        }
      });
    return () => ctl.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [site?.id, product.id, refreshKey]);

  useEffect(() => {
    setRvFrames([]);
    if (product.source !== 'rainviewer') return undefined;
    const ctl = new AbortController();
    fetchRainViewer(ctl.signal)
      .then((data) => {
        const frames = [...(data.radar?.past || []), ...(data.radar?.nowcast || [])];
        setRvHost(data.host || 'https://tilecache.rainviewer.com');
        setRvFrames(frames);
        anim.setFrameIndex(Math.max(0, frames.length - 1));
      })
      .catch(() => setError('RainViewer national mosaic is temporarily unavailable.'));
    return () => ctl.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [product.id, refreshKey]);

  const buildRadarCandidates = useCallback((nextProduct, nextSite, frame, newest, rvFrame) => {
    const commonWms = { ...RETINA_WMS_OPTIONS, opacity: 0, zIndex: 400, crossOrigin: true };
    const wms = (url, options, label) => ({ label, create: () => L.tileLayer.wms(url, { ...commonWms, ...options }) });

    if (nextProduct.source === 'site-adaptive' && nextSite) {
      if (!productSupportsSite(nextProduct, nextSite)) return [];
      const live = resolveSiteSource(nextProduct, nextSite, 'live');
      const archive = resolveSiteSource(nextProduct, nextSite, 'archive');
      if (!newest && archive?.source === 'iem-ridge') {
        return [wms(IEM_RIDGE, ridgeParams(nextSite.iemId || nextSite.id, archive.code, frame, false), 'IEM archive')];
      }
      const candidates = [];
      if (live?.source === 'noaa-opengeo') {
        candidates.push(wms(noaaOpenGeoWms(nextSite.icao), { layers: noaaOpenGeoLayer(nextSite.icao, live.code), version: '1.1.1', format: 'image/png', transparent: true }, 'NOAA/NCEP live'));
      }
      if (live?.source === 'iem-ridge') {
        candidates.push(wms(IEM_RIDGE, ridgeParams(nextSite.iemId || nextSite.id, live.code, frame, true), 'IEM live'));
      }
      if (archive?.source === 'iem-ridge' && live?.source !== 'iem-ridge') {
        candidates.push(wms(IEM_RIDGE, ridgeParams(nextSite.iemId || nextSite.id, archive.code, frame, true), 'IEM fallback'));
      }
      // Base reflectivity should never leave a selected operational radar on a
      // blank map just because one single-site service is delayed/outage. The
      // regional NOAA MRMS mosaic is a real radar fallback centered on the
      // selected site, so every operational radar dot still provides weather
      // context while the local feed recovers.
      if (nextProduct.id === 'n0b') {
        const regional = regionalBrefFallback(nextSite);
        candidates.push(wms(regional.url, { layers: regional.layer, version: '1.1.1', format: 'image/png', transparent: true }, regional.label));
      }
      return candidates;
    }
    if (nextProduct.source === 'noaa-opengeo' && nextSite) {
      if (!productSupportsSite(nextProduct, nextSite)) return [];
      return [wms(noaaOpenGeoWms(nextSite.icao), { layers: noaaOpenGeoLayer(nextSite.icao, nextProduct.code), version: '1.1.1', format: 'image/png', transparent: true }, 'NOAA/NCEP live')];
    }
    if (nextProduct.source === 'noaa-static-wms') return [wms(nextProduct.wmsUrl, { layers: nextProduct.layer, version: '1.1.1', format: 'image/png', transparent: true }, 'NOAA/NCEP MRMS')];
    if (nextProduct.source === 'iem-wms') return [wms(`${IEM_WMS_BASE}${nextProduct.cgi}`, { layers: nextProduct.layer, format: 'image/png', transparent: true }, 'Iowa Environmental Mesonet')];
    if (nextProduct.source === 'rainviewer' && rvFrame) return [{ label: 'RainViewer mosaic', create: () => L.tileLayer(rainViewerTile(rvHost, rvFrame.path, 6, 512), { opacity: 0, zIndex: 400, maxNativeZoom: 7, maxZoom: 19, crossOrigin: true, keepBuffer: 3 }) }];
    return [];
  }, [rvHost]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return undefined;
    if (product.source === 'aws-level3') {
      // Keep the last successfully rendered radar layer visible until the
      // Level III product has actually decoded. If the requested dual-pol
      // scan is delayed or missing, users still retain useful weather context
      // instead of dropping to a blank basemap.
      if (radarPendingLayerRef.current && map.hasLayer(radarPendingLayerRef.current)) map.removeLayer(radarPendingLayerRef.current);
      radarPendingLayerRef.current = null;
      radarBuildKey.current = '';
      return undefined;
    }
    if (!product.available || (isSiteProduct(product) && !productSupportsSite(product, site))) return undefined;

    const newest = displayFrames.length === 0 || anim.frameIndex >= displayFrames.length - 1;
    const rvFrame = product.source === 'rainviewer' ? (rvFrames[anim.frameIndex] || rvFrames.at(-1)) : null;
    const frameKey = product.source === 'rainviewer' ? rvFrame?.path || 'pending' : activeFrame?.toISOString?.() || (newest ? 'live' : 'static');
    const key = `${product.id}:${site?.icao || 'national'}:${frameKey}:${newest ? 'newest' : 'archive'}:${refreshKey}`;
    if (radarBuildKey.current === key && radarLayerRef.current) return undefined;
    radarBuildKey.current = key;

    const candidates = buildRadarCandidates(product, site, activeFrame, newest, rvFrame);
    if (!candidates.length) return undefined;
    let cancelled = false;
    let timeout = null;
    let pending = null;

    const cleanupPending = () => {
      if (timeout) clearTimeout(timeout);
      timeout = null;
      if (pending && map.hasLayer(pending)) map.removeLayer(pending);
      if (radarPendingLayerRef.current === pending) radarPendingLayerRef.current = null;
      pending = null;
    };

    const tryCandidate = (index) => {
      if (cancelled || index >= candidates.length) {
        if (!cancelled) setError('Selected radar feed is temporarily unavailable. Try refresh or another nearby radar.');
        return;
      }
      cleanupPending();
      const candidate = candidates[index];
      const layer = candidate.create();
      pending = layer; radarPendingLayerRef.current = layer;
      let committed = false; let tileLoads = 0;
      const commit = () => {
        if (cancelled || committed || radarPendingLayerRef.current !== layer) return;
        committed = true;
        if (timeout) clearTimeout(timeout);
        const old = radarLayerRef.current;
        layer.setOpacity?.(opacityRef.current);
        radarLayerRef.current = layer; radarPendingLayerRef.current = null; pending = null;
        setDataSourceLabel(candidate.label);
        setError((current) => current?.includes('feed is temporarily') ? '' : current);
        if (old && old !== layer && map.hasLayer(old)) setTimeout(() => mapRef.current?.hasLayer(old) && mapRef.current.removeLayer(old), 180);
      };
      const unavailable = () => {
        if (cancelled || committed) return;
        if (index + 1 < candidates.length) {
          tryCandidate(index + 1);
          return;
        }
        cleanupPending();
        radarBuildKey.current = '';
        if (isSiteProduct(product) && product.id !== 'n0b') {
          setError(`${product.short} is temporarily unavailable for ${site?.icao || 'this radar'}. Switched to Base Reflectivity.`);
          setProductId('n0b');
          return;
        }
        setError(`Radar imagery is temporarily unavailable for ${site?.icao || 'this view'}. The previous valid frame was kept on screen.`);
      };
      layer.on('tileload', () => { tileLoads += 1; });
      layer.on('load', () => {
        // Leaflet emits `load` after failed tiles too. Only promote the new
        // layer when at least one visible tile actually loaded successfully.
        if (tileLoads > 0) commit();
        else unavailable();
      });
      layer.addTo(map);
      timeout = setTimeout(() => {
        if (committed || cancelled) return;
        if (tileLoads > 0) commit();
        else unavailable();
      }, index + 1 < candidates.length ? 3200 : 4800);
    };

    tryCandidate(0);
    return () => { cancelled = true; cleanupPending(); };
  }, [product, site, activeFrame, anim.frameIndex, displayFrames.length, rvFrames, refreshKey, buildRadarCandidates]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return undefined;

    if (product.source !== 'aws-level3') {
      if (l3LayerRef.current && map.hasLayer(l3LayerRef.current)) map.removeLayer(l3LayerRef.current);
      l3LayerRef.current = null;
      l3IdentityRef.current = '';
      setL3Loading(false);
      return undefined;
    }

    // Clear only an in-progress raster request here. The last successfully
    // rendered raster remains as a safety layer until the new Level III frame
    // has decoded and is ready to replace it.
    if (radarPendingLayerRef.current && map.hasLayer(radarPendingLayerRef.current)) map.removeLayer(radarPendingLayerRef.current);
    radarPendingLayerRef.current = null;
    radarBuildKey.current = '';

    const identity = `${product.id}:${site?.id || ''}`;
    if (l3IdentityRef.current !== identity) {
      if (l3LayerRef.current && map.hasLayer(l3LayerRef.current)) map.removeLayer(l3LayerRef.current);
      l3LayerRef.current = null;
      l3IdentityRef.current = identity;
    }

    const selected = l3Frames[anim.frameIndex] || l3Frames.at(-1);
    const l3Product = getLevel3Product(product.id);
    if (!selected || !l3Product) return undefined;

    const ctl = new AbortController();
    let cancelled = false;
    setL3Loading(true);
    setError('');
    (async () => {
      try {
        let decoded = l3CacheRef.current.get(selected.key);
        if (!decoded) {
          const raw = await fetchLevel3File(selected.key, ctl.signal);
          decoded = await decodeLevel3(raw);
          l3CacheRef.current.set(selected.key, decoded);
          while (l3CacheRef.current.size > 5) l3CacheRef.current.delete(l3CacheRef.current.keys().next().value);
        }
        if (cancelled || !mapRef.current) return;
        const next = createRadialLayer(decoded, l3Product, opacityRef.current);
        next.addTo(map);
        const old = l3LayerRef.current;
        const oldRaster = radarLayerRef.current;
        l3LayerRef.current = next;
        setDataSourceLabel('NOAA / Unidata Level III');
        if (old && old !== next && map.hasLayer(old)) map.removeLayer(old);
        if (oldRaster && map.hasLayer(oldRaster)) {
          map.removeLayer(oldRaster);
          radarLayerRef.current = null;
        }
      } catch (e) {
        if (e.name !== 'AbortError' && !cancelled) {
          setError(`Could not decode ${product.short} for ${site?.icao || 'this radar'}. Switched to Base Reflectivity so the map stays operational.`);
          setProductId('n0b');
          radarBuildKey.current = '';
        }
      } finally {
        if (!cancelled) setL3Loading(false);
      }
    })();
    return () => { cancelled = true; ctl.abort(); };
  }, [product.id, product.source, product.short, site?.id, l3Frames, anim.frameIndex, refreshKey]);

  useEffect(() => {
    radarLayerRef.current?.setOpacity?.(opacity);
    l3LayerRef.current?.setOpacity?.(opacity);
  }, [opacity]);

  const clearOverlay = useCallback((name) => {
    const map = mapRef.current;
    const layer = overlayRefs.current[name];
    if (map && layer) map.removeLayer(layer);
    overlayRefs.current[name] = null;
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    ['states', 'counties', 'cwa'].forEach((name) => {
      clearOverlay(name);
      if (overlays[name]) {
        const layer = L.tileLayer.wms(NOAA_REFERENCE_WMS, {
          ...RETINA_WMS_OPTIONS,
          layers: NOAA_BOUNDARY_LAYERS[name === 'states' ? 'state' : name === 'counties' ? 'county' : 'cwa'],
          format: 'image/png',
          transparent: true,
          opacity: 0.72,
          zIndex: 520,
        });
        layer.addTo(map);
        overlayRefs.current[name] = layer;
      }
    });
  }, [overlays.states, overlays.counties, overlays.cwa, clearOverlay]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    clearOverlay('radarSites');
    if (!overlays.radarSites) return;
    const g = L.layerGroup();
    sites.forEach((s) => {
      const selected = site?.icao === s.icao;
      L.circleMarker([s.lat, s.lon], {
        radius: selected ? 6 : 3.5,
        color: selected ? '#ffffff' : '#38d996',
        fillColor: selected ? '#38d996' : '#07130e',
        fillOpacity: 0.95,
        weight: selected ? 2 : 1,
      })
        .bindTooltip(`${escapeHtml(s.icao)} · ${escapeHtml(s.city)}`)
        .on('click', () => handleSiteSelect(s))
        .addTo(g);
    });
    g.addTo(map);
    overlayRefs.current.radarSites = g;
  }, [sites, site, overlays.radarSites, clearOverlay, handleSiteSelect]);

  useEffect(() => {
    const wants = overlays.tornadoWarning || overlays.severeWarning || overlays.flashFloodWarning || overlays.tornadoWatch || overlays.severeWatch;
    clearOverlay('alerts');
    if (!wants || !mapRef.current) return undefined;
    const ctl = new AbortController();
    fetchNwsAlerts(ctl.signal)
      .then((data) => {
        const g = L.layerGroup();
        (data.features || []).forEach((f) => {
          if (!f.geometry || !alertEnabled(f.properties?.event, overlays)) return;
          L.geoJSON(f, { style: () => alertStyle(f.properties?.event) })
            .bindPopup(`<b>${escapeHtml(f.properties?.event)}</b><br>${escapeHtml(f.properties?.areaDesc)}<br><span style="color:#9aa3b2">${escapeHtml(f.properties?.headline)}</span>`)
            .addTo(g);
        });
        g.addTo(mapRef.current);
        overlayRefs.current.alerts = g;
      })
      .catch(() => {});
    return () => ctl.abort();
  }, [overlays.tornadoWarning, overlays.severeWarning, overlays.flashFloodWarning, overlays.tornadoWatch, overlays.severeWatch, clearOverlay]);

  useEffect(() => {
    clearOverlay('lsr');
    if (!overlays.lsr || !mapRef.current) return undefined;
    const ctl = new AbortController();
    fetchLsr(ctl.signal)
      .then((data) => {
        const g = L.layerGroup();
        (data.features || data.lsr || []).forEach((f) => {
          const p = f.properties || f;
          const c = f.geometry?.coordinates;
          const lat = Number(c?.[1] ?? p.lat ?? p.latitude);
          const lon = Number(c?.[0] ?? p.lon ?? p.longitude);
          if (!Number.isFinite(lat) || !Number.isFinite(lon)) return;
          L.circleMarker([lat, lon], { radius: 4, color: '#facc15', fillColor: '#111827', fillOpacity: 0.9, weight: 1 })
            .bindPopup(`<b>${escapeHtml(p.typetext || p.type || p.event || 'Storm Report')}</b><br>${escapeHtml(p.remark || p.description || '')}`)
            .addTo(g);
        });
        g.addTo(mapRef.current);
        overlayRefs.current.lsr = g;
      })
      .catch(() => {});
    return () => ctl.abort();
  }, [overlays.lsr, clearOverlay]);

  useEffect(() => {
    clearOverlay('spc');
    if (!overlays.spc || !mapRef.current) return undefined;
    const ctl = new AbortController();
    fetchSpcOutlook(ctl.signal)
      .then((data) => {
        const layer = L.geoJSON(data, {
          style: (f) => ({
            color: f.properties?.stroke || '#a78bfa',
            weight: 1.5,
            fillColor: f.properties?.fill || '#a78bfa',
            fillOpacity: 0.08,
          }),
        });
        layer.addTo(mapRef.current);
        overlayRefs.current.spc = layer;
      })
      .catch(() => {});
    return () => ctl.abort();
  }, [overlays.spc, clearOverlay]);

  useEffect(() => {
    clearOverlay('nhc');
    if (!overlays.nhc || !mapRef.current) return undefined;
    const ctl = new AbortController();
    fetchNhcStorms(ctl.signal)
      .then((data) => {
        const storms = data.activeStorms || data.storms || [];
        const g = L.layerGroup();
        storms.forEach((s) => {
          const lat = parseCoordinate(s.latitude ?? s.lat, s.latitudeNumeric, 'lat');
          const lon = parseCoordinate(s.longitude ?? s.lon, s.longitudeNumeric, 'lon');
          if (!Number.isFinite(lat) || !Number.isFinite(lon)) return;
          L.circleMarker([lat, lon], { radius: 7, color: '#f472b6', fillColor: '#831843', fillOpacity: 0.85, weight: 2 })
            .bindPopup(`<b>${escapeHtml(s.name || s.stormName || 'Tropical Cyclone')}</b>`)
            .addTo(g);
        });
        g.addTo(mapRef.current);
        overlayRefs.current.nhc = g;
      })
      .catch(() => {});
    return () => ctl.abort();
  }, [overlays.nhc, clearOverlay]);

  useEffect(() => {
    clearOverlay('rangeRings');
    if (!overlays.rangeRings || !mapRef.current || !site) return;
    const g = L.layerGroup();
    RANGE_RINGS.forEach(({ miles, km }) => {
      L.circle([site.lat, site.lon], {
        radius: km * 1000,
        color: '#38d996',
        weight: 1,
        opacity: 0.52,
        fill: false,
        dashArray: '5 6',
        interactive: false,
      }).addTo(g);
      const labelPoint = destinationPoint(site.lat, site.lon, 35, km);
      L.marker(labelPoint, {
        interactive: false,
        icon: L.divIcon({
          className: 'srn-range-ring-label',
          html: `${miles} mi`,
          iconSize: null,
        }),
      }).addTo(g);
    });
    g.addTo(mapRef.current);
    overlayRefs.current.rangeRings = g;
  }, [overlays.rangeRings, site, clearOverlay]);

  useEffect(() => {
    clearOverlay('measurement');
    if (!mapRef.current || measurePoints.length === 0) return;
    const g = L.layerGroup();
    measurePoints.forEach((point, index) => {
      L.circleMarker([point.lat, point.lng], {
        radius: 5,
        color: '#ffffff',
        fillColor: '#38d996',
        fillOpacity: 1,
        weight: 2,
      }).bindTooltip(index === 0 ? 'Start' : 'End').addTo(g);
    });
    if (measurePoints.length === 2) {
      const [a, b] = measurePoints;
      L.polyline([[a.lat, a.lng], [b.lat, b.lng]], {
        color: '#38d996',
        weight: 2,
        opacity: 0.9,
        dashArray: '7 5',
      }).addTo(g);
      if (measureResult) {
        const mid = [(a.lat + b.lat) / 2, (a.lng + b.lng) / 2];
        L.marker(mid, {
          interactive: false,
          icon: L.divIcon({
            className: 'srn-range-ring-label',
            html: `${measureResult.miles.toFixed(1)} mi · ${Math.round(measureResult.bearing)}°`,
            iconSize: null,
          }),
        }).addTo(g);
      }
    }
    g.addTo(mapRef.current);
    overlayRefs.current.measurement = g;
  }, [measurePoints, measureResult, clearOverlay]);

  const handleMobileSheetChange = useCallback(() => {
    setTimeout(() => mapRef.current?.invalidateSize(), 120);
  }, []);

  const handleNearest = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by this browser.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const found = nearestSite(sites, pos.coords.latitude, pos.coords.longitude);
        if (found) handleSiteSelect(found.site);
      },
      () => setError('Location permission was denied or unavailable.'),
    );
  };

  const handleProductSelect = (id) => {
    const nextProduct = findProduct(id);
    if (isSiteProduct(nextProduct) && !productSupportsSite(nextProduct, site)) {
      const found = nearestWsrSite(sites, site.lat, site.lon);
      if (found?.site) {
        setSite(found.site);
        setProductId(id);
        setError(`${nextProduct.short} requires WSR-88D. Switched to ${found.site.icao} · ${found.site.city} (${Math.round(found.distanceKm)} km away).`);
      } else setError(`${nextProduct.label} requires a WSR-88D site.`);
    } else {
      setProductId(id); setError('');
    }
    setInspector(null); radarBuildKey.current = '';
  };

  const opacityControl = <div><div className="mb-2 flex justify-between font-data text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--srn-dim))]"><span>Radar opacity</span><span>{Math.round(opacity * 100)}%</span></div><input type="range" min="20" max="100" value={Math.round(opacity * 100)} onChange={(e) => setOpacity(Number(e.target.value) / 100)} className="w-full"/></div>;

  const toolsPanel = <RadarToolsPanel rangeRings={overlays.rangeRings} onToggleRangeRings={() => setOverlays((v) => ({ ...v, rangeRings: !v.rangeRings }))} measureMode={measureMode} onToggleMeasure={() => { setMeasureMode((v) => !v); setProbeMode(false); setInspector(null); setMeasurePoints([]); }} measureResult={measureResult} onClearMeasure={() => setMeasurePoints([])} probeMode={probeMode} onToggleProbe={() => { setProbeMode((v) => !v); setMeasureMode(false); setMeasurePoints([]); if (probeMode) setInspector(null); }}/>

  const controls = (
    <div className="space-y-5">
      <SiteSelector sites={sites} selected={site} onSelect={handleSiteSelect} onNearest={handleNearest} loading={sitesLoading}/>
      <ProductMenu selectedId={productId} onSelect={handleProductSelect} site={site}/>
      <ElevationSelector product={product}/>
      <SiteInfoPanel site={site} product={product} frame={activeFrame} error={error} sourceLabel={dataSourceLabel}/>
      {opacityControl}
      {toolsPanel}
      <OverlayPanel overlays={overlays} onToggle={(id) => setOverlays((v) => ({ ...v, [id]: !v[id] }))}/>
      <RadarLegend product={product}/>
    </div>
  );

  const mobileSections = [
    { id: 'site', label: 'Site', content: <div className="space-y-4"><SiteSelector sites={sites} selected={site} onSelect={handleSiteSelect} onNearest={handleNearest} loading={sitesLoading}/><SiteInfoPanel site={site} product={product} frame={activeFrame} error={error} sourceLabel={dataSourceLabel}/>{opacityControl}</div> },
    { id: 'products', label: 'Products', content: <div className="space-y-4"><ProductMenu selectedId={productId} onSelect={handleProductSelect} site={site}/><ElevationSelector product={product}/><RadarLegend product={product}/></div> },
    { id: 'layers', label: 'Layers', content: <OverlayPanel overlays={overlays} onToggle={(id) => setOverlays((v) => ({ ...v, [id]: !v[id] }))}/> },
    { id: 'tools', label: 'Tools', content: <div className="space-y-4">{toolsPanel}<div className="flex items-center justify-between gap-3"><span className="font-data text-[10px] uppercase srn-status-text">Animation speed</span><select value={anim.speed} onChange={(e) => anim.setSpeed(Number(e.target.value))} className="h-10 border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel))] px-2 font-data text-[10px]"><option value={1200}>0.5×</option><option value={800}>1×</option><option value={450}>2×</option><option value={250}>3×</option></select></div></div> },
  ];

  return (
    <>
      <div className={`${fullscreen ? 'fixed inset-0 z-[1100] bg-[hsl(var(--srn-void))]' : 'relative'} overflow-hidden border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel))]`}>
        <div className={`grid lg:grid-cols-[350px_1fr] ${fullscreen ? 'h-full min-h-0' : 'lg:min-h-[720px]'}`}>
          <aside className={`${fullscreen ? 'max-h-none' : 'max-h-[820px]'} hidden overflow-y-auto border-r border-[hsl(var(--srn-line))] p-4 lg:block`}>{controls}</aside>
          <div className={`relative ${fullscreen ? 'min-h-0' : 'h-[68svh] min-h-[520px] max-h-[760px] lg:h-auto lg:min-h-[620px] lg:max-h-none'}`}>
            <div ref={mapEl} className={`absolute inset-0 ${measureMode ? 'cursor-crosshair' : ''}`} />
            <div className="pointer-events-none absolute left-3 top-3 z-[700] max-w-[65%] border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.95)] px-3 py-2 shadow-lg backdrop-blur">
              <p className="font-data text-[9px] uppercase tracking-[0.16em] srn-status-text">{product.scope === 'site' ? `${site.icao} · ${site.city}` : 'National / Mosaic'}</p>
              <p className="font-cmd text-lg font-bold uppercase tracking-[0.08em]">{product.label}</p>
              <p className="mt-0.5 font-data text-[8px] uppercase tracking-[0.12em] text-[hsl(var(--srn-dim))]">{l3Loading ? 'Decoding Level III scan…' : `${site?.type === 'TDWR' && product.scope === 'site' ? 'TDWR · ' : product.scope === 'site' ? 'WSR-88D · ' : ''}${dataSourceLabel}`}</p>
            </div>
            <div className="absolute right-3 top-3 z-[700] flex gap-2">
              {measureMode && <button type="button" onClick={() => { setMeasureMode(false); setMeasurePoints([]); }} className="grid h-11 w-11 place-items-center border border-[hsl(var(--srn-status)/0.65)] bg-[hsl(var(--srn-void)/0.95)] shadow-lg" title="Exit distance / bearing tool"><Ruler className="h-4 w-4 srn-status-text" /></button>}
              <button type="button" onClick={() => { radarBuildKey.current = ''; setRefreshKey((v) => v + 1); }} className="grid h-11 w-11 place-items-center border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.95)] shadow-lg" title="Refresh radar"><RefreshCw className="h-4 w-4" /></button>
              <button type="button" onClick={() => { if (site.type === 'TDWR') { const found = nearestWsrSite(sites, site.lat, site.lon); if (found?.site) { setSite(found.site); setError(`Storm Analysis uses WSR-88D. Switched to ${found.site.icao}.`); } } setComparison(true); }} className="grid h-11 w-11 place-items-center border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.95)] shadow-lg" title="Storm analysis quad"><Grid2X2 className="h-4 w-4" /></button>
              <button type="button" onClick={() => setFullscreen((v) => !v)} className="grid h-11 w-11 place-items-center border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.95)] shadow-lg" title={fullscreen ? 'Exit full screen (Esc)' : 'Full screen'}>{fullscreen ? <Minimize className="h-4 w-4" /> : <Expand className="h-4 w-4" />}</button>
            </div>
            <div className="absolute left-3 right-3 top-[5.3rem] z-[690] flex gap-1 overflow-x-auto rounded-sm border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void)/0.9)] p-1 shadow-lg backdrop-blur [scrollbar-width:none] lg:left-auto lg:right-3 lg:max-w-[560px]">
              {QUICK_PRODUCTS.map((id) => { const item = findProduct(id); const active = item.id === productId; const supported = productSupportsSite(item, site); return <button key={id} type="button" onClick={() => handleProductSelect(id)} className={`min-h-9 shrink-0 rounded-sm border px-2.5 font-data text-[9px] font-bold uppercase tracking-[0.1em] ${active ? 'border-[hsl(var(--srn-status))] bg-[hsl(var(--srn-status)/0.16)] text-[hsl(var(--srn-status))]' : supported ? 'border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel)/0.8)] text-[hsl(var(--srn-text))]' : 'border-[hsl(var(--srn-amber)/0.45)] text-[hsl(var(--srn-amber))]'}`}>{item.short}</button>; })}
            </div>
            {error && <div className="absolute left-3 right-3 top-[8.35rem] z-[700] flex items-center gap-2 border border-[hsl(var(--srn-amber)/0.5)] bg-[hsl(var(--srn-void)/0.94)] px-3 py-2 text-xs text-[hsl(var(--srn-amber))]"><TriangleAlert className="h-4 w-4" />{error}</div>}
            <RadarInspector value={probeMode ? inspector : null} onClose={() => setInspector(null)} />
            <div className="absolute inset-x-0 bottom-0 z-[650]"><AnimationBar frames={displayFrames} anim={anim} enabled={!!product.animated} /></div>
            <MobileControlSheet onOpenChange={handleMobileSheetChange} sections={mobileSections}/>
          </div>
        </div>
      </div>
      <div className="mt-3 grid gap-3 text-[11px] leading-relaxed text-[hsl(var(--srn-dim))] md:grid-cols-[1fr_auto] md:items-start">
        <p><b className="text-[hsl(var(--srn-text))]">Sources:</b> NOAA/NWS/NCEI, NOAA/NCEP OpenGeo, Unidata NEXRAD Level III on AWS Open Data, Iowa Environmental Mesonet, RainViewer, OpenStreetMap and CARTO. Product availability varies by provider and radar site.</p>
        <a href="https://radar.weather.gov/" target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-data text-[10px] uppercase tracking-[0.12em] srn-status-text"><LocateFixed className="h-3.5 w-3.5" />Official NWS Radar</a>
      </div>
      {comparison && <ComparisonGrid site={site} onClose={() => setComparison(false)} />}
    </>
  );
}
