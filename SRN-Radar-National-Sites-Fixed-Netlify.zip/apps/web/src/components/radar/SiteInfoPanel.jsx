import React from 'react';

function fallbackSource(product) {
  if (product.source === 'site-adaptive') return 'NOAA/NCEP + IEM fallback';
  if (product.source === 'iem-ridge' || product.source === 'iem-wms') return 'Iowa Environmental Mesonet';
  if (product.source === 'noaa-opengeo' || product.source === 'noaa-static-wms') return 'NOAA / NCEP OpenGeo';
  if (product.source === 'rainviewer') return 'RainViewer';
  if (product.source === 'aws-level3') return 'NOAA / Unidata Level III';
  return 'Public weather data';
}

export default function SiteInfoPanel({ site, product, frame, error, sourceLabel }) {
  if (!site) return null;
  const ageMinutes = frame ? Math.max(0, Math.round((Date.now() - frame.getTime()) / 60_000)) : null;
  const stale = Number.isFinite(ageMinutes) && ageMinutes > 20;
  return <div className="srn-panel rounded-sm p-3 text-xs">
    <div className="flex items-start justify-between gap-3"><div><p className="font-cmd text-lg font-bold uppercase tracking-[0.1em]">{site.icao} · {site.city}</p><p className="mt-0.5 font-data text-[9px] uppercase tracking-[0.12em] text-[hsl(var(--srn-dim))]">{site.type === 'TDWR' ? 'Terminal Doppler Weather Radar' : 'WSR-88D NEXRAD'}</p></div><span className="font-data text-[9px] uppercase srn-status-text">{site.state}</span></div>
    <div className="mt-3 grid grid-cols-2 gap-2 font-data text-[10px] text-[hsl(var(--srn-dim))]"><span>Product<br/><b className="text-[hsl(var(--srn-text))]">{product.label}</b></span><span>Elevation<br/><b className="text-[hsl(var(--srn-text))]">{product.elevation || (product.scope === 'site' ? 'Source-defined' : 'N/A')}</b></span><span>Lat/Lon<br/><b className="text-[hsl(var(--srn-text))]">{site.lat.toFixed(3)}, {site.lon.toFixed(3)}</b></span><span>Scan<br/><b className="text-[hsl(var(--srn-text))]">{frame ? `${frame.toISOString().slice(11,16)} UTC` : 'Latest'}</b></span><span className="col-span-2">Active feed<br/><b className="text-[hsl(var(--srn-text))]">{sourceLabel || fallbackSource(product)}</b></span></div>
    {Number.isFinite(ageMinutes) && <p className={`mt-3 border-l-2 pl-2 text-[10px] ${stale ? 'border-[hsl(var(--srn-amber))] text-[hsl(var(--srn-amber))]' : 'srn-status-border text-[hsl(var(--srn-dim))]'}`}>Data age: ~{ageMinutes} min{stale ? ' · feed may be stale' : ''}</p>}
    {error && <p className="mt-3 border-l-2 border-[hsl(var(--srn-amber))] pl-2 text-[10px] text-[hsl(var(--srn-amber))]">{error}</p>}
  </div>;
}
