import React, { useMemo, useState } from 'react';
import { Crosshair, Search } from 'lucide-react';
import { searchSites } from '@/lib/radar/sites';

export default function SiteSelector({ sites, selected, onSelect, onNearest, loading }) {
  const [query, setQuery] = useState('');
  const results = useMemo(() => searchSites(sites, query, Math.max(sites.length, 250)), [sites, query]);
  return (
    <div>
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="font-data text-[10px] uppercase tracking-[0.2em] srn-status-text">Radar Site</p>
        <button type="button" onClick={onNearest} className="inline-flex min-h-9 items-center gap-1 rounded-sm border border-[hsl(var(--srn-line))] px-2 text-[10px] uppercase tracking-[0.12em] text-[hsl(var(--srn-dim))] hover:text-[hsl(var(--srn-text))]"><Crosshair className="h-3.5 w-3.5" />Nearest</button>
      </div>
      <div className="relative"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-[hsl(var(--srn-dim))]"/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="KMAF, KLBB, TDFW, city, state…" className="w-full rounded-sm border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void))] py-2.5 pl-9 pr-3 text-sm outline-none focus:border-[hsl(var(--srn-status))]"/></div>
      <div className="mt-2 max-h-52 overflow-y-auto rounded-sm border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void))]">
        {loading && <p className="px-3 py-2 font-data text-[10px] uppercase tracking-[0.12em] text-[hsl(var(--srn-dim))]">Loading NOAA radar network…</p>}
        {results.map((s) => <button key={s.icao} type="button" onClick={() => { onSelect(s); setQuery(''); }} className={`flex min-h-12 w-full items-center justify-between gap-2 border-b border-[hsl(var(--srn-line))] px-3 py-2 text-left text-xs last:border-b-0 hover:bg-[hsl(var(--srn-panel-2))] ${selected?.icao === s.icao ? 'bg-[hsl(var(--srn-status)/0.12)]' : ''}`}>
          <span><b className="font-data srn-status-text">{s.icao}</b> · {s.city}</span><span className="text-right font-data text-[9px] uppercase text-[hsl(var(--srn-dim))]">{s.state}<br/>{s.type === 'TDWR' ? 'TDWR' : 'WSR-88D'}</span>
        </button>)}
      </div>
    </div>
  );
}
