export const SITE_CONFIG = {
    name: 'Storm Response Network',
    shortName: 'SRN',
    tagline: 'Chase • Report • Protect',
    established: 2026,
    discordUrl: 'https://discord.gg/VcFufHRCkz',
    facebookUrl: 'https://www.facebook.com/share/14iKBEFskTh/?mibextid=wwXIfr',
    cashAppUrl: 'https://cash.app/$grahambutler07',
    cashAppHandle: '$grahambutler07',
    contactEmail: '', // Add an organization-controlled public email when ready.
    organizationStatus: 'Nonprofit organization in formation',
    nonprofitNotice: 'SRN is developing its nonprofit structure. Contributions are not represented as tax-deductible unless SRN explicitly states otherwise after receiving the appropriate recognition.',
    operations: {
        label: 'Normal Operations',
        shortLabel: 'Normal Ops',
        detail: 'Routine nationwide automated weather monitoring, preparedness, training, and network development.',
    },
};

export default SITE_CONFIG;
