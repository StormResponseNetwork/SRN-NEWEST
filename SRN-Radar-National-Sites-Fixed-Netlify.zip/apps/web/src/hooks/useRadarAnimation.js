import { useEffect, useState } from 'react';

export default function useRadarAnimation(frameCount, defaultPlaying = false) {
  const [frameIndex, setFrameIndex] = useState(Math.max(0, frameCount - 1));
  const [playing, setPlaying] = useState(defaultPlaying);
  const [speed, setSpeed] = useState(700);
  const [loop, setLoop] = useState(true);

  useEffect(() => {
    setFrameIndex((i) => Math.min(Math.max(0, frameCount - 1), i));
  }, [frameCount]);

  useEffect(() => {
    if (!playing || frameCount < 2) return undefined;
    const id = setInterval(() => {
      setFrameIndex((i) => {
        if (i >= frameCount - 1) {
          if (!loop) { setPlaying(false); return i; }
          return 0;
        }
        return i + 1;
      });
    }, speed);
    return () => clearInterval(id);
  }, [playing, speed, loop, frameCount]);

  return {
    frameIndex,
    setFrameIndex,
    playing,
    setPlaying,
    speed,
    setSpeed,
    loop,
    setLoop,
    prev: () => setFrameIndex((i) => Math.max(0, i - 1)),
    next: () => setFrameIndex((i) => Math.min(Math.max(0, frameCount - 1), i + 1)),
    newest: () => setFrameIndex(Math.max(0, frameCount - 1)),
  };
}
