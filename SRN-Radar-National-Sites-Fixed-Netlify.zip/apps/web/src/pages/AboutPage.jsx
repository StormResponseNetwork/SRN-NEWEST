import React from 'react';
import { Helmet } from 'react-helmet';
import { Antenna, CloudLightning, MapPin, MapPinned, Radio, ShieldAlert, ShieldCheck, Users } from 'lucide-react';
import Seo from '@/components/Seo';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import Reveal from '@/components/Reveal';
import { SITE_CONFIG } from '@/config/site';

const HERO_IMG = 'https://images.hostinger.com/5e306372-07f7-4935-bf32-6442a2585011.png';

const pillars = [
  { icon: CloudLightning, title: 'Weather Awareness', body: 'Make official weather information easier to find, understand, and act on.' },
  { icon: MapPinned, title: 'Ground Truth', body: 'Encourage timely, accurate, clearly located field observations without overstating what is known.' },
  { icon: Antenna, title: 'Communications', body: 'Promote resilient amateur-radio and digital communications for weather and preparedness activities.' },
  { icon: ShieldAlert, title: 'Preparedness', body: 'Support practical training, safety, and community readiness before severe weather arrives.' },
];

const founderCredentials = [
  'SKYWARN trained storm spotter',
  'Amateur radio operator — KJ5PGB',
  'FEMA ICS-100',
  'FEMA ICS-200',
  'FEMA IS-700',
  'FEMA IS-800',
  'ARES involvement',
  'Emergency-management volunteer experience',
  'CPR/AED training',
  'Stop the Bleed training',
];

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-[hsl(var(--srn-void))]">
      <Helmet>
        <title>About SRN — Storm Response Network</title>
        <meta name="description" content="Learn about Storm Response Network, an independent volunteer weather and preparedness organization established in 2026." />
      </Helmet>
      <Seo title="About SRN — Storm Response Network" description="Mission, purpose, and operating principles of Storm Response Network." image={HERO_IMG} siteName="Storm Response Network" />
      <SiteHeader />
      <section className="relative overflow-hidden border-b border-[hsl(var(--srn-line))] py-16 lg:py-24">
        <img src={HERO_IMG} alt="Severe weather operations" className="absolute inset-0 h-full w-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--srn-void))] via-[hsl(var(--srn-void)/0.82)] to-[hsl(var(--srn-void)/0.64)]" />
        <div className="relative mx-auto max-w-[90rem] px-5 lg:px-8">
          <span className="srn-chip"><Users className="h-3.5 w-3.5" strokeWidth={2} />Established {SITE_CONFIG.established}</span>
          <h1 className="mt-6 font-cmd text-5xl font-bold uppercase leading-[0.92] tracking-tight sm:text-6xl lg:text-7xl">About <span className="srn-status-text">SRN</span></h1>
          <p className="mt-5 max-w-3xl text-base leading-relaxed text-[hsl(var(--srn-dim))]">Storm Response Network is an independent volunteer weather, communications, preparedness, and disaster-support organization. Our goal is simple: improve situational awareness, encourage accurate ground reporting, and help communities prepare before conditions become dangerous.</p>
          <p className="mt-4 font-data text-xs uppercase tracking-[0.2em] srn-status-text">{SITE_CONFIG.tagline}</p>
        </div>
      </section>
      <section className="py-20 lg:py-28">
        <div className="mx-auto max-w-[90rem] px-5 lg:px-8">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {pillars.map((p, i) => (
              <Reveal key={p.title} y={14} delay={i * 0.04}>
                <article className="srn-panel h-full p-7">
                  <p.icon className="h-7 w-7 srn-status-text" strokeWidth={1.6} />
                  <h2 className="mt-5 font-cmd text-2xl font-bold uppercase tracking-wide">{p.title}</h2>
                  <p className="mt-3 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">{p.body}</p>
                </article>
              </Reveal>
            ))}
          </div>

          <Reveal y={18}>
            <section className="srn-panel mt-12 overflow-hidden" aria-labelledby="founder-heading">
              <div className="grid lg:grid-cols-[minmax(260px,0.72fr)_1.8fr]">
                <div className="flex min-h-[320px] items-center justify-center border-b border-[hsl(var(--srn-line))] bg-[radial-gradient(circle_at_top,hsl(var(--srn-status)/0.12),transparent_55%)] p-8 lg:border-b-0 lg:border-r">
                  <div className="text-center">
                    <div className="mx-auto w-48 overflow-hidden border border-[hsl(var(--srn-status)/0.45)] bg-[hsl(var(--srn-panel-2))] shadow-[0_0_45px_hsl(var(--srn-status)/0.12)]">
                      <img
                        src="/graham-butler-founder.jpg"
                        alt="Graham Butler, Founder and Director of Storm Response Network"
                        className="aspect-[265/393] h-auto w-full object-cover"
                      />
                    </div>
                    <p className="mt-5 font-data text-[10px] uppercase tracking-[0.2em] srn-status-text">Founder &amp; Director</p>
                    <p className="mt-1 text-xs text-[hsl(var(--srn-dim))]">Graham Butler</p>
                  </div>
                </div>
                <div className="p-7 lg:p-10">
                  <p className="font-data text-[10px] uppercase tracking-[0.24em] srn-status-text">Founder &amp; Director</p>
                  <h2 id="founder-heading" className="mt-2 font-cmd text-4xl font-bold uppercase tracking-wide sm:text-5xl">Graham Butler</h2>
                  <p className="mt-2 font-cmd text-xl font-semibold uppercase tracking-[0.08em] text-[hsl(var(--srn-text))]">Founder &amp; Director — Storm Response Network</p>
                  <p className="mt-3 inline-flex items-center gap-2 font-data text-[11px] uppercase tracking-[0.16em] text-[hsl(var(--srn-dim))]"><MapPin className="h-4 w-4 srn-status-text" />Martin County, Texas</p>

                  <p className="mt-6 max-w-4xl text-sm leading-7 text-[hsl(var(--srn-dim))]">Graham Butler founded Storm Response Network from an interest in severe weather, storm spotting, amateur radio, emergency communications, preparedness, and the value of accurate ground-truth weather information. His work with SRN focuses on building practical weather-information resources, encouraging responsible field reporting, strengthening communications, and helping communities stay better informed before and during severe weather.</p>

                  <div className="mt-7 grid gap-2 sm:grid-cols-2">
                    {founderCredentials.map((credential) => (
                      <div key={credential} className="flex min-h-11 items-center gap-2 border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel-2)/0.45)] px-3 py-2 text-xs text-[hsl(var(--srn-text)/0.9)]">
                        {credential.includes('KJ5PGB') ? <Radio className="h-4 w-4 shrink-0 srn-status-text" /> : <ShieldCheck className="h-4 w-4 shrink-0 srn-status-text" />}
                        <span>{credential}</span>
                      </div>
                    ))}
                  </div>
                  <p className="mt-5 text-xs leading-relaxed text-[hsl(var(--srn-dim))]">These items describe training and volunteer background only. SRN does not represent Graham as a meteorologist, law-enforcement officer, firefighter, or government official.</p>
                </div>
              </div>
            </section>
          </Reveal>

          <div className="mt-12 grid gap-6 lg:grid-cols-2">
            <article className="srn-panel p-7 lg:p-9">
              <h2 className="font-cmd text-3xl font-bold uppercase tracking-wide">Independent Organization</h2>
              <p className="mt-4 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">SRN is not the National Weather Service, NOAA, FEMA, law enforcement, fire service, or an emergency-management agency. Official warnings and public-safety instructions always come from the responsible government authority.</p>
            </article>
            <article className="srn-panel p-7 lg:p-9">
              <h2 className="font-cmd text-3xl font-bold uppercase tracking-wide">Join the Network</h2>
              <p className="mt-4 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">The SRN Discord community is the fastest way to follow development, participate in weather discussion, and learn about future volunteer opportunities.</p>
              <a href={SITE_CONFIG.discordUrl} target="_blank" rel="noreferrer" className="srn-btn mt-6">Join SRN Discord</a>
            </article>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
