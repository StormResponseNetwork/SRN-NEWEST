import React, { useEffect, useState, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { TriangleAlert, Loader2, RefreshCw, MapPin, Filter } from 'lucide-react';
import Seo from '@/components/Seo';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import Reveal from '@/components/Reveal';

const NWS_ALERTS = 'https://api.weather.gov/alerts/active?status=actual&message_type=alert';

const HERO_IMG = 'https://images.hostinger.com/5e306372-07f7-4935-bf32-6442a2585011.png';

const CATEGORIES = [
    { id: 'all', label: 'All Active' },
    { id: 'tornado', label: 'Tornado' },
    { id: 'severe', label: 'Severe Tstorm' },
    { id: 'flood', label: 'Flood' },
    { id: 'watch', label: 'Watches' },
    { id: 'other', label: 'Other' },
];

function classify(event) {
    const e = (event || '').toLowerCase();
    if (e.includes('tornado warning')) return 'tornado';
    if (e.includes('severe thunderstorm warning')) return 'severe';
    if (e.includes('flood warning') || e.includes('flash flood')) return 'flood';
    if (e.includes('watch')) return 'watch';
    return 'other';
}

function severityColor(event) {
    const c = classify(event);
    if (c === 'tornado') return '#ff2b2b';
    if (c === 'severe') return '#ffb020';
    if (c === 'flood') return '#22d3a6';
    if (c === 'watch') return '#ffd23b';
    return '#6b7280';
}

function fmtAgo(iso) {
    if (!iso) return '—';
    const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (mins <= 0) return 'just now';
    if (mins < 60) return `${mins} min ago`;
    const hrs = Math.round(mins / 60);
    if (hrs < 24) return `${hrs} hr ago`;
    return `${Math.round(hrs / 24)} d ago`;
}

export default function AlertsPage() {
    const [alerts, setAlerts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [filter, setFilter] = useState('all');
    const [query, setQuery] = useState('');
    const [lastRefresh, setLastRefresh] = useState(null);

    const fetchAlerts = useCallback(async (silent = false) => {
        if (!silent) setLoading(true);
        setError(null);
        try {
            const res = await fetch(NWS_ALERTS, { headers: { Accept: 'application/geo+json' } });
            if (!res.ok) throw new Error('Alert feed unavailable');
            const data = await res.json();
            const rows = (data.features || []).map((f) => ({
                id: f.id,
                event: f.properties?.event || 'Unknown',
                area: f.properties?.areaDesc || '',
                headline: f.properties?.headline || '',
                sent: f.properties?.sent,
                expires: f.properties?.expires,
                url: f.properties?.uri || f.id,
                cat: classify(f.properties?.event),
            }));
            rows.sort((a, b) => {
                const order = { tornado: 0, severe: 1, flood: 2, watch: 3, other: 4 };
                if (order[a.cat] !== order[b.cat]) return order[a.cat] - order[b.cat];
                return new Date(b.sent) - new Date(a.sent);
            });
            setAlerts(rows);
            setLastRefresh(Date.now());
        } catch (e) {
            if (!silent) setError(e.message);
        } finally {
            if (!silent) setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchAlerts(false);
        const id = setInterval(() => fetchAlerts(true), 60 * 1000);
        return () => clearInterval(id);
    }, [fetchAlerts]);

    const counts = alerts.reduce((acc, a) => { acc[a.cat] = (acc[a.cat] || 0) + 1; return acc; }, {});
    const visible = alerts.filter((a) => {
        if (filter !== 'all' && a.cat !== filter) return false;
        if (query) {
            const q = query.toLowerCase();
            return a.event.toLowerCase().includes(q) || a.area.toLowerCase().includes(q);
        }
        return true;
    });

    return (
        <div className="min-h-screen bg-[hsl(var(--srn-void))]">
            <Helmet>
                <title>Active Alerts — Storm Response Network</title>
                <meta name="description" content="Live active NWS watches, warnings and advisories across the United States, filterable by hazard type and area." />
            </Helmet>
            <Seo
                title="Active Alerts — Storm Response Network"
                description="Live active NWS watches, warnings and advisories, filterable by hazard type."
                image={HERO_IMG}
                siteName="Storm Response Network"
            />
            <SiteHeader />

            <section className="relative overflow-hidden border-b border-[hsl(var(--srn-line))] py-16 lg:py-24">
                <img src={HERO_IMG} alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" />
                <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--srn-void))] via-[hsl(var(--srn-void)/0.8)] to-[hsl(var(--srn-void)/0.6)]" />
                <div className="relative mx-auto max-w-[90rem] px-5 lg:px-8">
                    <span className="srn-chip"><span className="srn-pip" />Live · NWS api.weather.gov</span>
                    <h1 className="mt-6 font-cmd text-5xl font-bold uppercase leading-[0.92] tracking-tight sm:text-6xl lg:text-7xl">
                        Active <span className="srn-status-text">Alerts</span>
                    </h1>
                    <p className="mt-5 max-w-2xl text-base leading-relaxed text-[hsl(var(--srn-dim))]">
                        Every active watch, warning and advisory currently issued by the National Weather Service across the United States. Filter by hazard, search by state or county, and refresh every minute.
                    </p>
                </div>
            </section>

            <section className="py-12 lg:py-16">
                <div className="mx-auto max-w-[90rem] px-5 lg:px-8">
                    {/* control bar */}
                    <div className="flex flex-wrap items-center gap-3 border-b border-[hsl(var(--srn-line))] pb-5">
                        <span className="srn-chip"><TriangleAlert className="h-3.5 w-3.5" strokeWidth={2} />{alerts.length} Active</span>
                        <div className="flex flex-wrap items-center gap-2">
                            <Filter className="h-4 w-4 text-[hsl(var(--srn-dim))]" strokeWidth={2} />
                            {CATEGORIES.map((c) => (
                                <button
                                    key={c.id}
                                    onClick={() => setFilter(c.id)}
                                    className={`border px-3 py-1.5 font-data text-[10px] uppercase tracking-[0.16em] transition-colors ${
                                        filter === c.id
                                            ? 'border-[hsl(var(--srn-status)/0.6)] bg-[hsl(var(--srn-status)/0.12)] text-[hsl(var(--srn-text))]'
                                            : 'border-[hsl(var(--srn-line))] text-[hsl(var(--srn-dim))] hover:text-[hsl(var(--srn-text))]'
                                    }`}
                                >
                                    {c.label}{counts[c.id] ? ` · ${counts[c.id]}` : ''}
                                </button>
                            ))}
                        </div>
                        <input
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            aria-label="Search active alerts by hazard, state, or county"
                            placeholder="Search hazard, state or county…"
                            className="ml-auto w-full max-w-[260px] border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void))] px-3 py-2 font-data text-xs text-[hsl(var(--srn-text))] outline-none focus:border-[hsl(var(--srn-status)/0.6)]"
                        />
                        <button
                            onClick={() => fetchAlerts(false)}
                            className="flex items-center gap-2 border border-[hsl(var(--srn-line))] px-3 py-2 font-data text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--srn-dim))] transition-colors hover:text-[hsl(var(--srn-text))]"
                        >
                            <RefreshCw className="h-3.5 w-3.5" strokeWidth={2} />Refresh
                        </button>
                    </div>

                    {/* state */}
                    <div className="mt-6">
                        {loading && (
                            <div className="flex items-center gap-3 border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel))] px-5 py-8 font-data text-xs uppercase tracking-[0.18em] text-[hsl(var(--srn-dim))]">
                                <Loader2 className="h-4 w-4 animate-spin srn-status-text" strokeWidth={2} />Syncing active alerts…
                            </div>
                        )}
                        {!loading && error && (
                            <div className="border border-[hsl(var(--srn-amber)/0.5)] bg-[hsl(var(--srn-amber)/0.1)] px-5 py-8 font-data text-xs uppercase tracking-[0.18em] text-[hsl(var(--srn-amber))]">
                                {error} — retry with the refresh button.
                            </div>
                        )}
                        {!loading && !error && visible.length === 0 && (
                            <div className="border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel))] px-5 py-12 text-center font-data text-xs uppercase tracking-[0.18em] text-[hsl(var(--srn-dim))]">
                                No active alerts match this filter.
                            </div>
                        )}
                        {!loading && !error && visible.length > 0 && (
                            <div className="grid gap-3 lg:grid-cols-2">
                                {visible.map((a, i) => (
                                    <Reveal key={a.id} y={12} delay={Math.min(i * 0.02, 0.2)}>
                                        <a
                                            href={a.url}
                                            target="_blank"
                                            rel="noreferrer"
                                            className="srn-panel group flex h-full gap-4 p-5 transition-colors hover:bg-[hsl(var(--srn-panel-2))]"
                                        >
                                            <span className="mt-1 h-full w-[3px] shrink-0" style={{ background: severityColor(a.event) }} />
                                            <div className="min-w-0 flex-1">
                                                <div className="flex items-center gap-3">
                                                    <span className="font-data text-[10px] uppercase tracking-[0.2em]" style={{ color: severityColor(a.event) }}>{a.event}</span>
                                                    <span className="ml-auto font-data text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--srn-dim))]">{fmtAgo(a.sent)}</span>
                                                </div>
                                                <p className="mt-2 flex items-start gap-2 font-cmd text-lg uppercase tracking-wide text-[hsl(var(--srn-text))]">
                                                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[hsl(var(--srn-dim))]" strokeWidth={2} />
                                                    <span className="truncate">{a.area || 'Area not specified'}</span>
                                                </p>
                                                {a.headline && (
                                                    <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">{a.headline}</p>
                                                )}
                                                <p className="mt-3 font-data text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--srn-dim))]">
                                                    Expires {a.expires ? new Date(a.expires).toLocaleString([], { hour12: false }) : '—'} · Open on weather.gov →
                                                </p>
                                            </div>
                                        </a>
                                    </Reveal>
                                ))}
                            </div>
                        )}
                    </div>

                    {lastRefresh && (
                        <p className="mt-8 font-data text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--srn-dim))]">
                            Feed refreshed {new Date(lastRefresh).toLocaleTimeString([], { hour12: false })} · auto-refresh 1 min
                        </p>
                    )}
                </div>
            </section>

            <SiteFooter />
        </div>
    );
}
