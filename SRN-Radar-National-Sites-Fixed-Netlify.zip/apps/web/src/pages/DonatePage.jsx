import React from 'react';
import { Helmet } from 'react-helmet';
import { ArrowRight, BadgeDollarSign, HeartHandshake, Lock, Radio, ShieldCheck, Truck, Users } from 'lucide-react';
import Seo from '@/components/Seo';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import Reveal from '@/components/Reveal';
import { SITE_CONFIG } from '@/config/site';

const HERO_IMG = 'https://images.hostinger.com/9eb72d73-c853-4695-9f81-ccad67ce9b5a.png';

const uses = [
  { icon: Radio, title: 'Communications', body: 'Radios, antennas, batteries, charging equipment, and other communications hardware used for weather operations.' },
  { icon: Truck, title: 'Field Operations', body: 'Fuel, vehicle support, safety equipment, and approved deployment expenses for field observation and reporting.' },
  { icon: Users, title: 'Training & Preparedness', body: 'Training materials, preparedness resources, volunteer development, and community education.' },
  { icon: HeartHandshake, title: 'Disaster Support', body: 'Approved supplies and community-support activities associated with severe weather and disaster response.' },
];

export default function DonatePage() {
  return (
    <div className="min-h-screen bg-[hsl(var(--srn-void))]">
      <Helmet>
        <title>Support SRN — Storm Response Network</title>
        <meta name="description" content="Support Storm Response Network weather operations, communications readiness, volunteer training, and disaster-support activities." />
      </Helmet>
      <Seo title="Support SRN — Storm Response Network" description="Support Storm Response Network weather operations and preparedness." image={HERO_IMG} siteName="Storm Response Network" />
      <SiteHeader />

      <section className="relative overflow-hidden border-b border-[hsl(var(--srn-line))] py-16 lg:py-24">
        <img src={HERO_IMG} alt="Weather operations workspace" className="absolute inset-0 h-full w-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--srn-void))] via-[hsl(var(--srn-void)/0.82)] to-[hsl(var(--srn-void)/0.66)]" />
        <div className="relative mx-auto max-w-[90rem] px-5 lg:px-8">
          <span className="srn-chip"><BadgeDollarSign className="h-3.5 w-3.5" strokeWidth={2} />Support the Mission</span>
          <h1 className="mt-6 max-w-4xl font-cmd text-5xl font-bold uppercase leading-[0.92] tracking-tight sm:text-6xl lg:text-7xl">Support <span className="srn-status-text">SRN</span></h1>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-[hsl(var(--srn-dim))]">Community support helps SRN improve weather communications, field reporting, preparedness resources, and volunteer capability. We keep the purpose of every contribution clear and avoid promising tax treatment that has not been formally established.</p>
        </div>
      </section>

      <section className="py-20 lg:py-28">
        <div className="mx-auto grid max-w-[90rem] gap-8 px-5 lg:grid-cols-[1.1fr_.9fr] lg:px-8">
          <div>
            <h2 className="font-cmd text-4xl font-bold uppercase tracking-tight sm:text-5xl">Where Support Can Go</h2>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {uses.map((item, i) => (
                <Reveal key={item.title} y={14} delay={i * 0.04}>
                  <article className="srn-panel h-full p-6">
                    <item.icon className="h-6 w-6 srn-status-text" strokeWidth={1.6} />
                    <h3 className="mt-5 font-cmd text-xl font-bold uppercase tracking-wide">{item.title}</h3>
                    <p className="mt-3 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">{item.body}</p>
                  </article>
                </Reveal>
              ))}
            </div>
          </div>

          <Reveal y={16}>
            <aside className="srn-panel p-7 lg:p-8">
              <span className="srn-chip"><Lock className="h-3.5 w-3.5" strokeWidth={2} />External Payment</span>
              <h2 className="mt-6 font-cmd text-3xl font-bold uppercase tracking-wide">Donate through Cash App</h2>
              <p className="mt-4 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">Use the button below to open the current SRN support link in Cash App. Payment information is handled by Cash App and is not collected by this website.</p>
              <a href={SITE_CONFIG.cashAppUrl} target="_blank" rel="noreferrer" className="srn-btn mt-7 w-full">Open {SITE_CONFIG.cashAppHandle} <ArrowRight className="h-4 w-4" strokeWidth={2.25} /></a>
              <a href={SITE_CONFIG.discordUrl} target="_blank" rel="noreferrer" className="srn-btn-outline mt-3 w-full">Join SRN on Discord</a>
              <div className="mt-7 border-t border-[hsl(var(--srn-line))] pt-5">
                <div className="flex gap-3">
                  <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[hsl(var(--srn-amber))]" strokeWidth={1.8} />
                  <p className="text-xs leading-relaxed text-[hsl(var(--srn-dim))]">{SITE_CONFIG.nonprofitNotice}</p>
                </div>
              </div>
            </aside>
          </Reveal>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
