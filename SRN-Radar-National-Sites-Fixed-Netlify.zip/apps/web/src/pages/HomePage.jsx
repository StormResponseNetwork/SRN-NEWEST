import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Radio, ShieldAlert, Users, LifeBuoy, ArrowRight, Antenna, CloudLightning, MapPinned, ClipboardList, GraduationCap, TriangleAlert, BookOpen, MessageCircle, HeartHandshake } from 'lucide-react';
import Reveal from '@/components/Reveal';
import Seo from '@/components/Seo';
import RadarMap from '@/components/RadarMap';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { SITE_CONFIG } from '@/config/site';
const HERO_IMG = 'https://images.hostinger.com/5e306372-07f7-4935-bf32-6442a2585011.png';
const OPS_IMG = 'https://images.hostinger.com/9eb72d73-c853-4695-9f81-ccad67ce9b5a.png';
const capabilities = [{
  icon: CloudLightning,
  code: 'CAP-01',
  title: 'Weather Intelligence',
  body: 'Official NWS products, public weather data and forecast guidance organized into clear situational-awareness information for volunteers and the public.'
}, {
  icon: MapPinned,
  code: 'CAP-02',
  title: 'Ground Reports',
  body: 'Spotter and volunteer observations — including hail, wind damage, flooding and rotation — documented with time and location for accurate relay through appropriate reporting channels.'
}, {
  icon: Antenna,
  code: 'CAP-03',
  title: 'Communications Readiness',
  body: 'Amateur radio, digital communications and backup-power planning that support volunteer coordination when normal communications are limited.'
}, {
  icon: ShieldAlert,
  code: 'CAP-04',
  title: 'Emergency Preparedness',
  body: 'Pre-season checklists, go-kit standards, drills and training tracks that get households and volunteer units ready before activation.'
}, {
  icon: ClipboardList,
  code: 'CAP-05',
  title: 'Situation Reports',
  body: 'Structured situation-report templates for significant events, including impacts, observations, resource needs and forecast context when SRN activates.'
}, {
  icon: LifeBuoy,
  code: 'CAP-06',
  title: 'Disaster Support',
  body: 'Volunteer disaster-support coordination conducted only when appropriate, authorized and coordinated with local authorities or established relief organizations.'
}];
function SectionLabel({
  index,
  children
}) {
  return <div className="flex items-center gap-4">
            <span className="font-data text-[11px] tracking-[0.3em] srn-status-text">{index}</span>
            <span className="h-px w-10 srn-status-bg opacity-60" />
            <span className="font-data text-[11px] uppercase tracking-[0.3em] text-[hsl(var(--srn-dim))]">{children}</span>
        </div>;
}
export default function HomePage() {
  return <div className="min-h-screen bg-[hsl(var(--srn-void))]">
            <Helmet>
                <title>Storm Response Network — Emergency Operations Center</title>
                <meta name="description" content="Storm Response Network (SRN) emergency operations center: national operations status, live NWS radar, volunteer coordination, situation reports and disaster support." />
            </Helmet>
            <Seo title="Storm Response Network — Emergency Operations Center" description="Volunteer-led storm intelligence, communications readiness and disaster support coordination." image={HERO_IMG} siteName="Storm Response Network" />

            {/* ── ALERT TICKER ─────────────────────────────── */}
            <div className="srn-banner overflow-hidden">
                <div className="flex whitespace-nowrap py-2 text-[11px]">
                    <div className="flex animate-[srn-marquee_38s_linear_infinite] items-center gap-10 pr-10 motion-reduce:animate-none">
                        {Array.from({
            length: 2
          }).map((_, i) => <React.Fragment key={i}>
                                <span>SRN public operations site · Online</span>
                                <span>Automated NWS alert feed available</span>
                                <span>Interactive national radar online</span>
                                <span>Volunteer community open on Discord</span>
                                <span>Official warnings always take priority</span>
                            </React.Fragment>)}
                    </div>
                </div>
                <style>{'@keyframes srn-marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}'}</style>
            </div>

            <SiteHeader />

            {/* ── HERO ─────────────────────────────────────── */}
            <section className="relative flex min-h-[100dvh] items-end overflow-hidden">
                <img src={HERO_IMG} alt="Mobile command vehicle deployed at night beneath a severe storm" className="absolute inset-0 h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--srn-void))] via-[hsl(var(--srn-void)/0.72)] to-[hsl(var(--srn-void)/0.55)]" />
                <div className="srn-grid-overlay pointer-events-none absolute inset-0 opacity-40" />
                <div className="relative mx-auto w-full max-w-[90rem] px-5 pb-16 pt-32 lg:px-8 lg:pb-24">
                    <Reveal>
                        <span className="srn-chip"><span className="srn-pip"></span>SRN Online</span>
                    </Reveal>
                    <Reveal delay={0.08}>
                        <h1 className="mt-6 max-w-5xl font-cmd text-[3.25rem] font-bold uppercase leading-[0.92] tracking-[-0.01em] sm:text-7xl lg:text-[7.5rem]">
                            Storm Response<br />
                            <span className="srn-status-text">Network</span>
                        </h1>
                    </Reveal>
                    <Reveal delay={0.16}>
                        <p className="mt-7 max-w-2xl text-base leading-relaxed text-[hsl(var(--srn-dim))] sm:text-lg">
                            A volunteer-led severe-weather network built around official weather information, live radar, communications readiness and accurate ground reports. SRN helps members prepare, observe, report and stay connected during impactful weather.
                        </p>
                    </Reveal>
                    <Reveal delay={0.24}>
                        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
                            <a href="#status" className="srn-btn">Enter Operations Center <ArrowRight className="h-4 w-4" strokeWidth={2.25} /></a>
                            <a href={SITE_CONFIG.discordUrl} target="_blank" rel="noreferrer" className="srn-btn-outline">Join SRN Discord <MessageCircle className="h-4 w-4" strokeWidth={2} /></a>
                        </div>
                    </Reveal>
                    <div className="mt-14 grid max-w-4xl grid-cols-2 gap-y-6 border-t border-[hsl(var(--srn-line))] pt-6 sm:grid-cols-4">
                        {[
                            ['National', 'Alert coverage'],
                            ['1 min', 'Alert refresh'],
                            ['Live', 'Interactive radar'],
                            ['Open', 'Volunteer community'],
                        ].map(([value, label]) => (
                            <div key={label}>
                                <p className="font-data text-2xl font-semibold srn-status-text">{value}</p>
                                <p className="mt-1 font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--srn-dim))]">{label}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* ── NATIONAL OPERATIONS STATUS ───────────────── */}
            <section id="status" className="border-t border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-void))] py-20 lg:py-28">
                <div className="mx-auto max-w-[90rem] px-5 lg:px-8">
                    <SectionLabel index="01">Operational Picture</SectionLabel>
                    <div className="mt-5 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
                        <h2 className="font-cmd text-4xl font-bold uppercase tracking-tight sm:text-5xl lg:text-6xl">National Operations Status</h2>
                        <p className="font-data text-xs uppercase tracking-[0.18em] text-[hsl(var(--srn-dim))]">Live feed · NWS / RainViewer / IEM</p>
                    </div>

                    <div className="mt-10 grid gap-4 lg:grid-cols-3">
                        {[{
            icon: ShieldAlert,
            title: 'Official Alert Feed',
            value: 'NWS LIVE',
            note: 'Active watches, warnings and advisories are pulled from the National Weather Service and refreshed every minute on the alerts page.'
          }, {
            icon: Radio,
            title: 'Weather Data',
            value: 'ONLINE',
            note: 'The operations map combines public radar imagery, official warning polygons and storm-report overlays with source attribution.'
          }, {
            icon: Users,
            title: 'SRN Community',
            value: 'OPEN',
            note: 'Volunteer coordination and community discussion are available through the official SRN Discord server.'
          }].map(c => <Reveal key={c.title} y={18}>
                                <article className="srn-panel relative h-full p-6">
                                    <span className="absolute left-0 top-0 h-full w-[3px] srn-status-bg" />
                                    <div className="flex items-start justify-between">
                                        <c.icon className="h-6 w-6 srn-status-text" strokeWidth={1.6} />
                                        <span className="srn-chip"><span className="srn-pip" />Live</span>
                                    </div>
                                    <p className="mt-6 font-data text-[10px] uppercase tracking-[0.24em] text-[hsl(var(--srn-dim))]">{c.title}</p>
                                    <p className="mt-2 font-cmd text-4xl font-bold uppercase tracking-tight">{c.value}</p>
                                    <p className="mt-4 border-t border-dashed border-[hsl(var(--srn-line))] pt-4 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">{c.note}</p>
                                </article>
                            </Reveal>)}
                    </div>
                </div>
            </section>

            {/* ── LIVE RADAR EMBED SLOT ────────────────────── */}
            <section id="radar" className="border-t border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel-2)/0.4)] py-20 lg:py-28">
                <div className="mx-auto max-w-[90rem] px-5 lg:px-8">
                    <SectionLabel index="02">Sensor Feed</SectionLabel>
                    <div className="mt-5 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
                        <h2 className="max-w-3xl font-cmd text-4xl font-bold uppercase tracking-tight sm:text-5xl lg:text-6xl">Live Radar &amp; Hazard Map</h2>
                        <p className="max-w-md text-sm leading-relaxed text-[hsl(var(--srn-dim))]">
                            Use the interactive map below for national reflectivity, satellite imagery, official NWS warning polygons and recent storm reports. Data availability depends on each public provider.
                        </p>
                        <Link to="/radar" className="srn-btn-outline mt-5 min-h-11 px-5">Open Advanced Radar <ArrowRight className="h-4 w-4" /></Link>
                    </div>

                    <Reveal y={20}>
                        <div className="mt-10">
                            <RadarMap />
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* ── CAPABILITIES GRID ────────────────────────── */}
            <section id="capabilities" className="border-t border-[hsl(var(--srn-line))] py-20 lg:py-28">
                <div className="mx-auto max-w-[90rem] px-5 lg:px-8">
                    <SectionLabel index="03">Mission Set</SectionLabel>
                    <h2 className="mt-5 max-w-4xl font-cmd text-4xl font-bold uppercase tracking-tight sm:text-5xl lg:text-6xl">Six Operational Capabilities</h2>
                    <div className="mt-12 grid border-l border-t border-[hsl(var(--srn-line))] sm:grid-cols-2 lg:grid-cols-3">
                        {capabilities.map((c, i) => <Reveal key={c.title} y={16} delay={i * 0.05}>
                                <article className="group h-full border-b border-r border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel)/0.5)] p-7 transition-colors hover:bg-[hsl(var(--srn-panel))] lg:p-9">
                                    <div className="flex items-center justify-between">
                                        <c.icon className="h-7 w-7 srn-status-text transition-transform duration-300 group-hover:-translate-y-0.5" strokeWidth={1.5} />
                                        <span className="font-data text-[10px] tracking-[0.24em] text-[hsl(var(--srn-dim))]">{c.code}</span>
                                    </div>
                                    <h3 className="mt-7 font-cmd text-2xl font-bold uppercase tracking-wide">{c.title}</h3>
                                    <span className="mt-3 block h-px w-12 srn-status-bg transition-all duration-300 group-hover:w-20" />
                                    <p className="mt-4 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">{c.body}</p>
                                </article>
                            </Reveal>)}
                    </div>
                </div>
            </section>

            {/* ── NAVIGATE THE NETWORK ─────────────────────── */}
            <section className="border-t border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel-2)/0.4)] py-20 lg:py-28">
                <div className="mx-auto max-w-[90rem] px-5 lg:px-8">
                    <SectionLabel index="04">Explore</SectionLabel>
                    <div className="mt-5 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
                        <h2 className="max-w-3xl font-cmd text-4xl font-bold uppercase tracking-tight sm:text-5xl lg:text-6xl">Navigate the Network</h2>
                        <p className="max-w-md text-sm leading-relaxed text-[hsl(var(--srn-dim))]">
                            Jump to live hazard feeds, volunteer training tracks, and the official resource library.
                        </p>
                    </div>
                    <div className="mt-12 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                        {[{
            to: '/alerts',
            icon: TriangleAlert,
            code: 'NAV-01',
            title: 'Active Alerts',
            body: 'Every live NWS watch, warning and advisory — filter by hazard and search by state or county.'
          }, {
            to: '/radar',
            icon: CloudLightning,
            code: 'NAV-02',
            title: 'Advanced Radar',
            body: 'Single-site NEXRAD reflectivity, base velocity, storm-relative velocity, hydrometeor classification, precipitation and analysis overlays.'
          }, {
            to: '/training',
            icon: GraduationCap,
            code: 'NAV-03',
            title: 'Training & Certification',
            body: 'SKYWARN, MetEd, FEMA ICS, ARES and amateur-radio licensing tracks with direct registration links.'
          }, {
            to: '/resources',
            icon: BookOpen,
            code: 'NAV-04',
            title: 'Resources & Links',
            body: 'A curated directory of NWS, SPC, FEMA, ARRL and other official sources operators rely on.'
          }].map((c, i) => <Reveal key={c.to} y={16} delay={i * 0.05}>
                                <Link to={c.to} className="group flex h-full flex-col border border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel)/0.5)] p-7 transition-colors hover:bg-[hsl(var(--srn-panel))] lg:p-9">
                                    <div className="flex items-center justify-between">
                                        <c.icon className="h-7 w-7 srn-status-text transition-transform duration-300 group-hover:-translate-y-0.5" strokeWidth={1.5} />
                                        <span className="font-data text-[10px] tracking-[0.24em] text-[hsl(var(--srn-dim))]">{c.code}</span>
                                    </div>
                                    <h3 className="mt-7 font-cmd text-2xl font-bold uppercase tracking-wide">{c.title}</h3>
                                    <span className="mt-3 block h-px w-12 srn-status-bg transition-all duration-300 group-hover:w-20" />
                                    <p className="mt-4 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">{c.body}</p>
                                    <span className="mt-6 inline-flex items-center gap-2 font-cmd text-sm font-bold uppercase tracking-[0.14em] srn-status-text">
                                        Open <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" strokeWidth={2.25} />
                                    </span>
                                </Link>
                            </Reveal>)}
                    </div>
                </div>
            </section>

            {/* ── PUBLIC-SAFETY NOTICE ─────────────────────── */}
            <section className="border-t border-[hsl(var(--srn-line))] py-16 lg:py-20">
                <div className="mx-auto max-w-[72rem] px-5 lg:px-8">
                    <Reveal y={16}>
                        <div className="srn-panel relative overflow-hidden">
                            <div className="srn-hatch h-2 w-full" />
                            <div className="grid gap-8 p-7 lg:grid-cols-[auto_1fr] lg:p-10">
                                <div className="grid h-14 w-14 place-items-center border border-[hsl(var(--srn-amber)/0.5)] bg-[hsl(var(--srn-amber)/0.1)]">
                                    <ShieldAlert className="h-7 w-7 text-[hsl(var(--srn-amber))]" strokeWidth={1.6} />
                                </div>
                                <div>
                                    <h2 className="font-cmd text-3xl font-bold uppercase tracking-[0.08em] text-[hsl(var(--srn-amber))]">Public-Safety Notice</h2>
                                    <p className="mt-4 text-sm leading-relaxed text-[hsl(var(--srn-dim))] sm:text-base">
                                        Storm Response Network is not a warning-issuing authority. Official weather watches and warnings come from the National Weather Service; evacuation orders and other emergency instructions come from authorized public-safety officials. Always act on official guidance first — information published here is supplemental situational awareness and may lag or be incomplete during an active event.
                                    </p>
                                    <div className="mt-6 srn-banner-soft p-4 font-data text-xs uppercase tracking-[0.16em]">
                                        In a life-threatening emergency, call 911. Do not report emergencies through this site or over volunteer radio nets.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* ── DONATIONS / SUPPORT PANEL ────────────────── */}
            <section id="support" className="relative border-t border-[hsl(var(--srn-line))] py-20 lg:py-28">
                <img src={OPS_IMG} alt="Operators monitoring radar displays inside a mobile emergency operations trailer" className="absolute inset-0 h-full w-full object-cover opacity-20" />
                <div className="absolute inset-0 bg-[hsl(var(--srn-void)/0.88)]" />
                <div className="relative mx-auto max-w-[90rem] px-5 lg:px-8">
                    <SectionLabel index="05">Sustainment</SectionLabel>
                    <div className="mt-5 grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
                        <div>
                            <h2 className="max-w-4xl font-cmd text-4xl font-bold uppercase tracking-tight sm:text-5xl lg:text-6xl">
                                Help Build SRN's Field Capability
                            </h2>
                            <p className="mt-6 max-w-2xl text-base leading-relaxed text-[hsl(var(--srn-dim))]">
                                Community contributions can help support communications equipment, training, field readiness and other approved volunteer operational needs. The support page explains the current donation method, intended uses, and the organization’s current nonprofit-status notice.
                            </p>
                            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                                <Link to="/donate" className="srn-btn">Support SRN <HeartHandshake className="h-4 w-4" strokeWidth={2} /></Link>
                                <a href={SITE_CONFIG.discordUrl} target="_blank" rel="noreferrer" className="srn-btn-outline">Join SRN Discord <MessageCircle className="h-4 w-4" strokeWidth={2} /></a>
                            </div>
                        </div>
                        <div className="srn-panel p-7 lg:p-9">
                            <p className="font-data text-[10px] uppercase tracking-[0.22em] srn-status-text">Current Support Channel</p>
                            <p className="mt-4 font-cmd text-3xl font-bold uppercase tracking-wide">Cash App</p>
                            <p className="mt-2 font-data text-sm text-[hsl(var(--srn-dim))]">{SITE_CONFIG.cashAppHandle}</p>
                            <p className="mt-5 border-t border-[hsl(var(--srn-line))] pt-5 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">
                                SRN is currently in nonprofit formation. Contributions are not represented as tax-deductible unless and until SRN is confirmed as eligible to receive tax-deductible charitable contributions.
                            </p>
                            <Link to="/donate" className="mt-6 inline-flex items-center gap-2 font-cmd text-sm font-bold uppercase tracking-[0.14em] srn-status-text">
                                Donation details <ArrowRight className="h-4 w-4" strokeWidth={2.2} />
                            </Link>
                        </div>
                    </div>
                </div>
            </section>

            <SiteFooter />
        </div>;
}