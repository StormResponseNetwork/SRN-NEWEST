import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft, TriangleAlert } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

export default function NotFoundPage() {
  return (
    <div className="min-h-screen bg-[hsl(var(--srn-void))]">
      <Helmet><title>Page Not Found — Storm Response Network</title></Helmet>
      <SiteHeader />
      <main className="mx-auto grid min-h-[65vh] max-w-[72rem] place-items-center px-5 py-20 text-center lg:px-8">
        <div>
          <TriangleAlert className="mx-auto h-10 w-10 text-[hsl(var(--srn-amber))]" strokeWidth={1.5} />
          <p className="mt-5 font-data text-xs uppercase tracking-[0.24em] text-[hsl(var(--srn-dim))]">HTTP 404</p>
          <h1 className="mt-3 font-cmd text-5xl font-bold uppercase tracking-tight sm:text-6xl">Page Not Found</h1>
          <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-[hsl(var(--srn-dim))]">The page you requested does not exist or may have moved.</p>
          <Link to="/" className="srn-btn mt-8"><ArrowLeft className="h-4 w-4" strokeWidth={2.2} />Return to Operations</Link>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
