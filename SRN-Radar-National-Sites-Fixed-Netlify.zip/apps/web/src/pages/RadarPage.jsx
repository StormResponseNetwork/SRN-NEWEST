import React from 'react';
import { Helmet } from 'react-helmet';
import { Radar, ShieldAlert } from 'lucide-react';
import Seo from '@/components/Seo';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import RadarWorkstation from '@/components/radar/RadarWorkstation';

export default function RadarPage() {
  return <>
    <Helmet><title>Advanced Radar | Storm Response Network</title></Helmet>
    <Seo title="Advanced Radar | Storm Response Network" description="SRN advanced NEXRAD radar workstation with reflectivity, velocity, storm-relative velocity, hydrometeor classification, precipitation, alerts and storm reports." />
    <SiteHeader/>
    <main>
      <section className="border-b border-[hsl(var(--srn-line))] bg-[hsl(var(--srn-panel-2)/0.35)] py-12 lg:py-16">
        <div className="mx-auto max-w-[90rem] px-5 lg:px-8">
          <div className="flex items-start gap-4"><div className="grid h-12 w-12 shrink-0 place-items-center border srn-status-border bg-[hsl(var(--srn-status)/0.1)]"><Radar className="h-6 w-6 srn-status-text"/></div><div><p className="font-data text-[10px] uppercase tracking-[0.22em] srn-status-text">SRN Weather Operations</p><h1 className="mt-2 font-cmd text-4xl font-bold uppercase tracking-tight sm:text-5xl lg:text-6xl">Advanced NEXRAD Radar</h1><p className="mt-4 max-w-3xl text-sm leading-relaxed text-[hsl(var(--srn-dim))] sm:text-base">Select a WSR-88D site and interrogate verified public radar products, or switch to national mosaics and satellite imagery. Products without a verified browser-renderable source are shown honestly as unavailable instead of being fabricated.</p></div></div>
        </div>
      </section>
      <section className="py-5 lg:py-8"><div className="mx-auto max-w-[96rem] px-3 sm:px-5 lg:px-8"><RadarWorkstation/></div></section>
      <section className="pb-12"><div className="mx-auto max-w-[90rem] px-5 lg:px-8"><div className="srn-panel flex gap-4 p-5"><ShieldAlert className="h-6 w-6 shrink-0 text-[hsl(var(--srn-amber))]"/><div><h2 className="font-cmd text-xl font-bold uppercase tracking-[0.08em] text-[hsl(var(--srn-amber))]">Situational Awareness Only</h2><p className="mt-2 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">SRN radar products are provided for situational awareness and should not replace official National Weather Service warnings or instructions from public safety officials.</p></div></div></div></section>
    </main>
    <SiteFooter/>
  </>;
}
