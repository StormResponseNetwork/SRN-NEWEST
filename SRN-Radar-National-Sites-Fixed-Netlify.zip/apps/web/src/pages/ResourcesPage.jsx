import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import {
    Radio, ShieldAlert, BookOpen, ExternalLink, Satellite,
    CloudRain, Wind, Droplets, Thermometer, Globe, Siren, LifeBuoy,
} from 'lucide-react';
import Seo from '@/components/Seo';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import Reveal from '@/components/Reveal';
import { SITE_CONFIG } from '@/config/site';

const HERO_IMG = 'https://images.hostinger.com/5e306372-07f7-4935-bf32-6442a2585011.png';

const groups = [
    {
        heading: 'Storm Response Network',
        icon: Siren,
        items: [
            { title: 'SRN Discord Community', body: 'Join weather discussion, alerts, training updates, and network development.', link: SITE_CONFIG.discordUrl },
            { title: 'SRN Facebook', body: 'Follow public updates and community announcements.', link: SITE_CONFIG.facebookUrl },
            { title: 'Support SRN', body: 'Current contribution information and fundraising transparency.', link: '/donate', internal: true },
        ],
    },
    {
        heading: 'Forecast & Observation',
        icon: Satellite,
        items: [
            { title: 'NWS National Forecast', body: 'Point forecasts, watches & warnings.', link: 'https://www.weather.gov/' },
            { title: 'Storm Prediction Center', body: 'Convective outlooks, mesoscale discussions, fire weather.', link: 'https://www.spc.noaa.gov/' },
            { title: 'Weather Prediction Center', body: 'Excessive rainfall & winter weather outlooks.', link: 'https://www.wpc.ncep.noaa.gov/' },
            { title: 'NWS Radar (national)', body: 'Official NEXRAD mosaic.', link: 'https://radar.weather.gov/' },
            { title: 'GOES Satellite Imagery', body: 'Real-time geostationary satellite.', link: 'https://www.star.nesdis.noaa.gov/GOES/' },
            { title: 'College of DuPage NEXRAD', body: 'High-resolution single-site radar.', link: 'https://weather.cod.edu/satrad/' },
        ],
    },
    {
        heading: 'Hazards & Climatology',
        icon: CloudRain,
        items: [
            { title: 'SPC Severe Weather Map', body: 'Live tornado & severe reports.', link: 'https://www.spc.noaa.gov/climo/' },
            { title: 'NWS Weather & Hazards Viewer', body: 'Interactive observations, wind, gusts, hazards, and overlays.', link: 'https://www.weather.gov/wrh/hazards' },
            { title: 'National Water Prediction Service', body: 'Official river, flood and water forecast information.', link: 'https://water.noaa.gov/' },
            { title: 'USGS Water Data', body: 'Real-time stream gauges.', link: 'https://waterdata.usgs.gov/' },
            { title: 'NWS HeatRisk', body: 'Experimental HeatRisk outlook and heat guidance.', link: 'https://www.wpc.ncep.noaa.gov/heatrisk/' },
            { title: 'SPC Hail Reports', body: 'Today\'s hail climatology.', link: 'https://www.spc.noaa.gov/climo/online/' },
        ],
    },
    {
        heading: 'Emergency Management',
        icon: ShieldAlert,
        items: [
            { title: 'FEMA Preparedness', body: 'Build-a-kit, make-a-plan guidance.', link: 'https://www.ready.gov/' },
            { title: 'State Emergency Management', body: 'Find your state emergency management agency.', link: 'https://www.usa.gov/state-emergency-management' },
            { title: 'Ready.gov Hazards', body: 'Hazard-specific action guides.', link: 'https://www.ready.gov/be-informed' },
            { title: 'FEMA App', body: 'Alerts, shelters, and preparedness.', link: 'https://www.fema.gov/about/news-multimedia/mobile-products' },
            { title: 'Red Cross Disaster Services', body: 'Shelter list and recovery help.', link: 'https://www.redcross.org/get-help.html' },
            { title: 'NOAA Weather Radio', body: 'SAME-area alert radios.', link: 'https://www.weather.gov/nwr/' },
        ],
    },
    {
        heading: 'Amateur Radio & Comms',
        icon: Radio,
        items: [
            { title: 'ARRL Getting Licensed', body: 'Technician, General, Extra tracks.', link: 'https://www.arrl.org/getting-licensed' },
            { title: 'ARES Emergency Service', body: 'Public service comms training.', link: 'https://www.arrl.org/ares' },
            { title: 'HamStudy.org', body: 'Free exam practice & question pools.', link: 'https://hamstudy.org/' },
            { title: 'Repeaterbook', body: 'Worldwide repeater directory.', link: 'https://www.repeaterbook.com/' },
            { title: 'NTS Traffic Handling', body: 'National Traffic System radiograms.', link: 'https://www.arrl.org/nts' },
            { title: 'RACES Civil Emergency', body: 'Government emergency comms service.', link: 'https://www.arrl.org/ares-races-faq' },
        ],
    },
];

const quickIcons = [
    { icon: Wind, label: 'Wind' },
    { icon: Droplets, label: 'Flood' },
    { icon: Thermometer, label: 'Heat' },
    { icon: Globe, label: 'Climate' },
    { icon: Siren, label: 'Alerts' },
    { icon: LifeBuoy, label: 'Recovery' },
];

function SectionLabel({ index, children }) {
    return (
        <div className="flex items-center gap-4">
            <span className="font-data text-[11px] tracking-[0.3em] srn-status-text">{index}</span>
            <span className="h-px w-10 srn-status-bg opacity-60" />
            <span className="font-data text-[11px] uppercase tracking-[0.3em] text-[hsl(var(--srn-dim))]">{children}</span>
        </div>
    );
}

export default function ResourcesPage() {
    return (
        <div className="min-h-screen bg-[hsl(var(--srn-void))]">
            <Helmet>
                <title>Resources & Links — Storm Response Network</title>
                <meta name="description" content="Curated official weather, hazard, emergency management, and amateur radio resources from NWS, SPC, FEMA, ARRL and more." />
            </Helmet>
            <Seo
                title="Resources & Links — Storm Response Network"
                description="Official weather, hazard, FEMA and amateur radio resource links."
                image={HERO_IMG}
                siteName="Storm Response Network"
            />
            <SiteHeader />

            <section className="relative overflow-hidden border-b border-[hsl(var(--srn-line))] py-16 lg:py-24">
                <img src={HERO_IMG} alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" />
                <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--srn-void))] via-[hsl(var(--srn-void)/0.8)] to-[hsl(var(--srn-void)/0.6)]" />
                <div className="relative mx-auto max-w-[90rem] px-5 lg:px-8">
                    <span className="srn-chip"><BookOpen className="h-3.5 w-3.5" strokeWidth={2} />Reference Library</span>
                    <h1 className="mt-6 font-cmd text-5xl font-bold uppercase leading-[0.92] tracking-tight sm:text-6xl lg:text-7xl">
                        Resources &amp; <span className="srn-status-text">Links</span>
                    </h1>
                    <p className="mt-5 max-w-2xl text-base leading-relaxed text-[hsl(var(--srn-dim))]">
                        A curated directory of official agencies and widely used weather, preparedness and amateur-radio references. Each card opens the source directly in a new tab.
                    </p>
                    <div className="mt-8 flex flex-wrap gap-2">
                        {quickIcons.map((q) => (
                            <span key={q.label} className="inline-flex items-center gap-2 border border-[hsl(var(--srn-line))] px-3 py-1.5 font-data text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--srn-dim))]">
                                <q.icon className="h-3.5 w-3.5 srn-status-text" strokeWidth={2} />{q.label}
                            </span>
                        ))}
                    </div>
                </div>
            </section>

            <section className="py-20 lg:py-28">
                <div className="mx-auto max-w-[90rem] px-5 lg:px-8">
                    <SectionLabel index="01">Directory</SectionLabel>
                    <h2 className="mt-5 max-w-4xl font-cmd text-4xl font-bold uppercase tracking-tight sm:text-5xl lg:text-6xl">Weather & Preparedness Library</h2>

                    <div className="mt-12 space-y-16">
                        {groups.map((g) => (
                            <div key={g.heading}>
                                <div className="flex items-center gap-3 border-b border-[hsl(var(--srn-line))] pb-4">
                                    <g.icon className="h-6 w-6 srn-status-text" strokeWidth={1.6} />
                                    <h3 className="font-cmd text-2xl font-bold uppercase tracking-wide">{g.heading}</h3>
                                    <span className="ml-auto font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--srn-dim))]">{g.items.length} sources</span>
                                </div>
                                <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                                    {g.items.map((it, i) => {
                                        const content = (
                                            <>
                                                <div className="flex items-start justify-between gap-3">
                                                    <h4 className="font-cmd text-lg font-bold uppercase tracking-wide">{it.title}</h4>
                                                    {!it.internal && <ExternalLink className="mt-1 h-4 w-4 shrink-0 text-[hsl(var(--srn-dim))] transition-colors group-hover:text-[hsl(var(--srn-status))]" strokeWidth={2} />}
                                                </div>
                                                <p className="mt-2 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">{it.body}</p>
                                            </>
                                        );
                                        return (
                                            <Reveal key={it.title} y={12} delay={Math.min(i * 0.03, 0.18)}>
                                                {it.internal ? (
                                                    <Link to={it.link} className="srn-panel group flex h-full flex-col p-5 transition-colors hover:bg-[hsl(var(--srn-panel-2)/0.6)]">{content}</Link>
                                                ) : (
                                                    <a href={it.link} target="_blank" rel="noreferrer" className="srn-panel group flex h-full flex-col p-5 transition-colors hover:bg-[hsl(var(--srn-panel-2)/0.6)]">{content}</a>
                                                )}
                                            </Reveal>
                                        );
                                    })}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            <SiteFooter />
        </div>
    );
}
