import React from 'react';
import { Helmet } from 'react-helmet';
import {
    CloudLightning, GraduationCap, Radio, ShieldCheck, BookOpen,
    Antenna, Phone, ExternalLink, Award, Users, Zap, Satellite,
} from 'lucide-react';
import Seo from '@/components/Seo';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import Reveal from '@/components/Reveal';
import { SITE_CONFIG } from '@/config/site';

const HERO_IMG = 'https://images.hostinger.com/9eb72d73-c853-4695-9f81-ccad67ce9b5a.png';

const tracks = [
    {
        icon: CloudLightning,
        code: 'TRK-01',
        title: 'SKYWARN Spotter Training',
        org: 'National Weather Service',
        body: 'Free official spotter program. Learn to identify storm features, report severe weather accurately, and coordinate with your local forecast office. In-person and online classes offered seasonally.',
        link: 'https://www.weather.gov/skywarn/',
        cta: 'Find a SKYWARN Class',
        reqs: ['Training length varies by WFO', 'Follow local WFO reporting guidance', 'Take refreshers as your local office recommends'],
    },
    {
        icon: BookOpen,
        code: 'TRK-02',
        title: 'MetEd · COMET',
        org: 'UCAR / NOAA',
        body: 'Hundreds of free, self-paced meteorology and hydrology modules from beginner mesoscale concepts to advanced convective forecasting. Certificates available on completion.',
        link: 'https://www.meted.ucar.edu/',
        cta: 'Browse MetEd Modules',
        reqs: ['Free account', 'Self-paced', 'Completion certificates'],
    },
    {
        icon: ShieldCheck,
        code: 'TRK-03',
        title: 'FEMA Independent Study',
        org: 'FEMA / NDEMU',
        body: 'Emergency management foundations including ICS, NIMS and National Response Framework coursework. Free online independent-study courses with FEMA/NDEMU completion certificates.',
        link: 'https://training.fema.gov/programs/independent-study/',
        cta: 'FEMA EMI Catalog',
        reqs: ['IS-100.c & IS-700.b foundations', 'IS-200.c & IS-800.d recommended next', 'Free · self-paced'],
    },
    {
        icon: Radio,
        code: 'TRK-04',
        title: 'ARES Emergency Comms',
        org: 'ARRL Amateur Radio Relay League',
        body: 'Amateur Radio Emergency Service training for public service and disaster communications. Net operations, message handling, and served-agency coordination.',
        link: 'https://www.arrl.org/ares',
        cta: 'ARES Training Portal',
        reqs: ['Valid amateur license', 'Local ARES registration', 'Local training requirements vary'],
    },
    {
        icon: Antenna,
        code: 'TRK-05',
        title: 'Amateur Radio Licensing',
        org: 'ARRL / FCC',
        body: 'Technician, General and Amateur Extra license tracks. Study guides, exam pools, and find a local VE exam session. Recommended for SRN members who plan to participate in amateur-radio communications activities.',
        link: 'https://www.arrl.org/getting-licensed',
        cta: 'Start Licensing Track',
        reqs: ['Technician (entry)', 'General (HF access)', 'Pass VE exam session'],
    },
    {
        icon: Award,
        code: 'TRK-06',
        title: 'Net Control Operator',
        org: 'SRN Internal',
        body: 'SRN net-control development covers directed-net discipline, logging, traffic handling and relay procedures. Availability and prerequisites are coordinated through the SRN community.',
        link: SITE_CONFIG.discordUrl,
        cta: 'Ask About SRN Training',
        reqs: ['Amateur license for on-air practice', 'SKYWARN strongly recommended', 'Mentored net practice'],
    },
];

const resources = [
    { icon: Phone, title: 'NOAA Weather Radio', body: 'Same-area alerts and broadcasts.', link: 'https://www.weather.gov/nwr/' },
    { icon: Satellite, title: 'Storm Prediction Center', body: 'Convective outlooks & mesoscale discussions.', link: 'https://www.spc.noaa.gov/' },
    { icon: Zap, title: 'NWS Watch & Warning Map', body: 'Official active hazard map.', link: 'https://www.weather.gov/' },
    { icon: Users, title: 'State Emergency Management', body: 'Find your state emergency management agency.', link: 'https://www.usa.gov/state-emergency-management' },
];

function SectionLabel({ index, children }) {
    return (
        <div className="flex items-center gap-4">
            <span className="font-data text-[11px] tracking-[0.3em] srn-status-text">{index}</span>
            <span className="h-px w-10 srn-status-bg opacity-60" />
            <span className="font-data text-[11px] uppercase tracking-[0.3em] text-[hsl(var(--srn-dim))]">{children}</span>
        </div>
    );
}

export default function TrainingPage() {
    return (
        <div className="min-h-screen bg-[hsl(var(--srn-void))]">
            <Helmet>
                <title>Training & Certification — Storm Response Network</title>
                <meta name="description" content="Volunteer training tracks for SRN: SKYWARN spotter training, MetEd meteorology, FEMA ICS, ARES emergency communications, and amateur radio licensing." />
            </Helmet>
            <Seo
                title="Training & Certification — Storm Response Network"
                description="SKYWARN, MetEd, FEMA, ARES and amateur-radio licensing tracks for storm response volunteers."
                image={HERO_IMG}
                siteName="Storm Response Network"
            />
            <SiteHeader />

            {/* hero */}
            <section className="relative overflow-hidden border-b border-[hsl(var(--srn-line))] py-16 lg:py-24">
                <img src={HERO_IMG} alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" />
                <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--srn-void))] via-[hsl(var(--srn-void)/0.8)] to-[hsl(var(--srn-void)/0.6)]" />
                <div className="relative mx-auto max-w-[90rem] px-5 lg:px-8">
                    <span className="srn-chip"><GraduationCap className="h-3.5 w-3.5" strokeWidth={2} />Volunteer Development</span>
                    <h1 className="mt-6 font-cmd text-5xl font-bold uppercase leading-[0.92] tracking-tight sm:text-6xl lg:text-7xl">
                        Training &amp; <span className="srn-status-text">Certification</span>
                    </h1>
                    <p className="mt-5 max-w-2xl text-base leading-relaxed text-[hsl(var(--srn-dim))]">
                        Build a strong severe-weather foundation with official spotter training, meteorology fundamentals, emergency-management coursework and amateur-radio resources. Requirements can vary by role and local agency.
                    </p>
                    <div className="mt-8 flex flex-wrap gap-3">
                        <a href="#tracks" className="srn-btn">View Training Tracks</a>
                        <a href="#resources" className="srn-btn-outline">Quick Resources</a>
                    </div>
                </div>
            </section>

            {/* tracks */}
            <section id="tracks" className="border-t border-[hsl(var(--srn-line))] py-20 lg:py-28">
                <div className="mx-auto max-w-[90rem] px-5 lg:px-8">
                    <SectionLabel index="01">Curriculum</SectionLabel>
                    <h2 className="mt-5 max-w-4xl font-cmd text-4xl font-bold uppercase tracking-tight sm:text-5xl lg:text-6xl">Six Training Tracks</h2>
                    <div className="mt-12 grid gap-4 lg:grid-cols-2">
                        {tracks.map((t, i) => (
                            <Reveal key={t.title} y={16} delay={i * 0.04}>
                                <article className="srn-panel group flex h-full flex-col p-7 transition-colors hover:bg-[hsl(var(--srn-panel-2)/0.6)] lg:p-8">
                                    <div className="flex items-center justify-between">
                                        <t.icon className="h-7 w-7 srn-status-text" strokeWidth={1.5} />
                                        <span className="font-data text-[10px] tracking-[0.24em] text-[hsl(var(--srn-dim))]">{t.code}</span>
                                    </div>
                                    <h3 className="mt-6 font-cmd text-2xl font-bold uppercase tracking-wide">{t.title}</h3>
                                    <p className="mt-1 font-data text-[10px] uppercase tracking-[0.18em] srn-status-text">{t.org}</p>
                                    <p className="mt-4 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">{t.body}</p>
                                    <ul className="mt-5 space-y-1.5">
                                        {t.reqs.map((r) => (
                                            <li key={r} className="flex items-center gap-2 font-data text-[11px] uppercase tracking-[0.12em] text-[hsl(var(--srn-dim))]">
                                                <span className="h-1.5 w-1.5 srn-status-bg" />{r}
                                            </li>
                                        ))}
                                    </ul>
                                    <a
                                        href={t.link}
                                        target="_blank"
                                        rel="noreferrer"
                                        className="mt-6 inline-flex items-center gap-2 self-start border border-[hsl(var(--srn-status)/0.55)] bg-[hsl(var(--srn-status)/0.08)] px-4 py-2.5 font-cmd text-sm font-bold uppercase tracking-[0.14em] text-[hsl(var(--srn-status))] transition-colors hover:bg-[hsl(var(--srn-status)/0.16)]"
                                    >
                                        {t.cta} <ExternalLink className="h-3.5 w-3.5" strokeWidth={2} />
                                    </a>
                                </article>
                            </Reveal>
                        ))}
                    </div>
                </div>
            </section>

            {/* resources */}
            <section id="resources" className="border-t border-[hsl(var(--srn-line))] py-20 lg:py-28">
                <div className="mx-auto max-w-[90rem] px-5 lg:px-8">
                    <SectionLabel index="02">Quick Reference</SectionLabel>
                    <h2 className="mt-5 max-w-4xl font-cmd text-4xl font-bold uppercase tracking-tight sm:text-5xl lg:text-6xl">Official Resources</h2>
                    <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                        {resources.map((r, i) => (
                            <Reveal key={r.title} y={14} delay={i * 0.04}>
                                <a
                                    href={r.link}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="srn-panel group flex h-full flex-col p-6 transition-colors hover:bg-[hsl(var(--srn-panel-2)/0.6)]"
                                >
                                    <r.icon className="h-6 w-6 srn-status-text" strokeWidth={1.6} />
                                    <h3 className="mt-5 font-cmd text-lg font-bold uppercase tracking-wide">{r.title}</h3>
                                    <p className="mt-2 text-sm leading-relaxed text-[hsl(var(--srn-dim))]">{r.body}</p>
                                    <span className="mt-4 inline-flex items-center gap-1.5 font-data text-[10px] uppercase tracking-[0.18em] text-[hsl(var(--srn-dim))] transition-colors group-hover:text-[hsl(var(--srn-status))]">
                                        Open <ExternalLink className="h-3 w-3" strokeWidth={2} />
                                    </span>
                                </a>
                            </Reveal>
                        ))}
                    </div>
                </div>
            </section>

            <SiteFooter />
        </div>
    );
}
